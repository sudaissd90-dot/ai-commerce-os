# ==================================================
# AI E-COMMERCE AUTOPILOT SYSTEM
# Version: 1.4
# AI QUALITY CONTROL AGENT
# ==================================================

from datetime import datetime


class QualityControlAI:

    def __init__(self, agent_name):
        self.agent_name = agent_name
        self.results = []


    def boot_agent(self):

        print("=" * 55)
        print("🛡️ AI QUALITY CONTROL AGENT")
        print("=" * 55)
        print("Agent:", self.agent_name)
        print("Status: ACTIVE ✅")
        print("Time:", datetime.now())
        print("=" * 55)



    def check_product(
        self,
        name,
        profit_score,
        competition_score,
        risk_score
    ):

        print("\n🔎 QUALITY CHECK")
        print("Product:", name)


        issues = []


        if profit_score < 6:
            issues.append(
                "Low Profit Margin"
            )


        if competition_score > 8:
            issues.append(
                "High Competition"
            )


        if risk_score > 7:
            issues.append(
                "High Return Risk"
            )



        if len(issues) == 0:

            status = "APPROVED FOR TESTING ✅"
            risk_level = "LOW"

        else:

            status = "REJECTED ❌"
            risk_level = "HIGH"



        result = {

            "product": name,
            "risk_level": risk_level,
            "issues": issues,
            "status": status

        }


        self.results.append(result)



    def report(self):

        print("\n🛡️ QUALITY CONTROL REPORT")
        print("-" * 45)


        for item in self.results:

            print(
                "\nProduct:",
                item["product"]
            )

            print(
                "Risk Level:",
                item["risk_level"]
            )

            print(
                "Issues:",
                item["issues"]
            )

            print(
                "Decision:",
                item["status"]
            )



# ==========================
# TEST AGENT
# ==========================


qc = QualityControlAI(
    "Product Safety Inspector"
)


qc.boot_agent()


qc.check_product(
    "Smart LED Cabinet Light",
    profit_score=8,
    competition_score=7,
    risk_score=3
)


qc.check_product(
    "Low Quality Gadget",
    profit_score=4,
    competition_score=9,
    risk_score=9
)


qc.report()