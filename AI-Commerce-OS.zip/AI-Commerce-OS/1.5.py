# ==================================================
# AI E-COMMERCE AUTOPILOT SYSTEM
# Version: 1.5
# AI PRODUCT SCORING ENGINE
# ==================================================

from datetime import datetime


class ProductScoringAI:

    def __init__(self, agent_name):
        self.agent_name = agent_name
        self.products = []


    def boot_agent(self):

        print("=" * 55)
        print("⭐ AI PRODUCT SCORING ENGINE")
        print("=" * 55)
        print("Agent:", self.agent_name)
        print("Status: ACTIVE ✅")
        print("Time:", datetime.now())
        print("=" * 55)



    def calculate_score(
        self,
        name,
        demand,
        profit,
        competition,
        trend,
        risk
    ):

        print("\n🧠 SCORING PRODUCT")
        print("Product:", name)


        # Competition aur risk mein
        # kam score better hota hai

        competition_score = 10 - competition
        risk_score = 10 - risk


        final_score = (
            demand +
            profit +
            competition_score +
            trend +
            risk_score
        ) / 5


        if final_score >= 8:

            decision = (
                "WINNER PRODUCT ⭐"
            )

        elif final_score >= 6:

            decision = (
                "NEEDS MORE RESEARCH ⚠️"
            )

        else:

            decision = (
                "REJECT PRODUCT ❌"
            )


        product = {

            "name": name,
            "final_score": round(final_score, 2),
            "decision": decision

        }


        self.products.append(product)



    def report(self):

        print("\n📊 FINAL PRODUCT SCORE REPORT")
        print("-" * 45)


        for product in self.products:

            print(
                "\nProduct:",
                product["name"]
            )

            print(
                "Final Score:",
                product["final_score"],
                "/10"
            )

            print(
                "AI Decision:",
                product["decision"]
            )



# ==========================
# TEST ENGINE
# ==========================


scorer = ProductScoringAI(
    "Decision Making Agent"
)


scorer.boot_agent()


scorer.calculate_score(
    "Smart LED Cabinet Light",
    demand=9,
    profit=8,
    competition=7,
    trend=8,
    risk=3
)


scorer.calculate_score(
    "Low Quality Gadget",
    demand=4,
    profit=4,
    competition=9,
    trend=3,
    risk=9
)


scorer.report()