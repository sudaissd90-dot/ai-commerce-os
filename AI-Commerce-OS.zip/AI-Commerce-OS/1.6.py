# ==================================================
# AI E-COMMERCE AUTOPILOT SYSTEM
# AI CUSTOMER REVIEW ANALYZER
# Code No: 7
# Version: 1.6
# ==================================================


class AI_Review_Analyzer:


    def __init__(self):
        self.status = "ONLINE"



    def analyze_reviews(self, product_name):

        print("=" * 55)
        print("⭐ AI CUSTOMER REVIEW ANALYZER")
        print("=" * 55)


        reviews = [

            "Very useful product and easy to use",
            "Good quality but packaging can improve",
            "Works perfectly for daily needs",
            "Price is slightly high"

        ]


        positive_points = 0
        problems = 0


        print("\n📦 Product:")
        print(product_name)


        print("\n📝 Customer Reviews Analysis")
        print("-" * 40)


        for review in reviews:

            print("➡️", review)


            if "good" in review.lower() or "useful" in review.lower() or "perfectly" in review.lower():
                positive_points += 1


            if "improve" in review.lower() or "high" in review.lower():
                problems += 1



        print("\n📊 AI REPORT")
        print("-" * 40)

        print("Positive Points:",
              positive_points)

        print("Problems Found:",
              problems)



        if positive_points > problems:
            print("\n🚀 AI Decision: PRODUCT QUALITY ACCEPTABLE")

        else:
            print("\n⚠️ AI Decision: NEEDS IMPROVEMENT")



# ===============================
# SYSTEM TEST
# ===============================


REVIEW_AI = AI_Review_Analyzer()


REVIEW_AI.analyze_reviews(
    "Car Phone Holder"
)