# ==================================================
# AI E-COMMERCE AUTOPILOT SYSTEM
# AI INVENTORY & STOCK MANAGER
# Code No: 9
# Version: 1.8
# ==================================================


class AI_Inventory_Manager:


    def __init__(self):
        self.status = "ONLINE"



    def check_stock(self, product_name, stock):

        print("=" * 55)
        print("📦 AI INVENTORY & STOCK MANAGER")
        print("=" * 55)


        print("\nProduct:")
        print(product_name)


        print("Current Stock:")
        print(stock, "Units")


        print("\n📊 INVENTORY STATUS")
        print("-" * 40)



        if stock == 0:

            print("❌ OUT OF STOCK")
            print("Action: Order New Inventory")


        elif stock <= 10:

            print("⚠️ LOW STOCK ALERT")
            print("Action: Prepare Restock")


        else:

            print("✅ STOCK LEVEL GOOD")
            print("Action: Continue Selling")



        print("\n🚀 Inventory Check Completed")



# ===============================
# SYSTEM TEST
# ===============================


INVENTORY_AI = AI_Inventory_Manager()


INVENTORY_AI.check_stock(
    "Car Phone Holder",
    25
)