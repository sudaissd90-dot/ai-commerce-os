# ==================================================
# AI E-COMMERCE AUTOPILOT SYSTEM
# AI ORDER MANAGEMENT SYSTEM
# Code No: 10
# Version: 1.9
# ==================================================


class AI_Order_Manager:


    def __init__(self):
        self.status = "ONLINE"
        self.orders = []



    def create_order(self, customer, product, quantity):

        print("=" * 55)
        print("📦 AI ORDER MANAGEMENT SYSTEM")
        print("=" * 55)


        order = {

            "customer": customer,
            "product": product,
            "quantity": quantity,
            "status": "PROCESSING"

        }


        self.orders.append(order)


        print("\n✅ New Order Created")

        print("Customer:",
              customer)

        print("Product:",
              product)

        print("Quantity:",
              quantity)

        print("Status:",
              "PROCESSING")



    def show_orders(self):

        print("\n📋 ORDER DATABASE")
        print("-" * 40)


        for number, order in enumerate(self.orders, 1):

            print(
                number,
                order
            )


        print("\n🚀 Order Management Completed")



# ===============================
# SYSTEM TEST
# ===============================


ORDER_AI = AI_Order_Manager()


ORDER_AI.create_order(
    "Customer A",
    "Car Phone Holder",
    2
)


ORDER_AI.show_orders()