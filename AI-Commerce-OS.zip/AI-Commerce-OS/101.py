# ==================================================
# AI E-COMMERCE AUTOPILOT SYSTEM
# AI REAL PRODUCT HUNTER AGENT
# Code No: 101
# Version: 3.0
# ==================================================


class AI_Real_Product_Hunter_Agent:

    def __init__(self):

        self.products = []

        print("=" * 70)
        print("🔍 AI REAL PRODUCT HUNTER AGENT")
        print("=" * 70)



    # ------------------------------------------------

    def add_product(
        self,
        name,
        demand,
        competition,
        profit
    ):

        self.products.append({

            "Name": name,
            "Demand": demand,
            "Competition": competition,
            "Profit": profit

        })


        print(
            "✅ Product Analyzed:",
            name
        )



    # ------------------------------------------------

    def find_best_product(self):

        print("\n📊 PRODUCT HUNTING REPORT")
        print("-" * 50)


        best_product = None
        best_score = 0


        for product in self.products:

            score = (
                product["Demand"]
                +
                product["Profit"]
                -
                product["Competition"]
            )


            print("\n📦 Product:",
                  product["Name"])

            print("Demand:",
                  product["Demand"])

            print("Competition:",
                  product["Competition"])

            print("Profit:",
                  product["Profit"])

            print("AI Score:",
                  score)


            if score > best_score:

                best_score = score
                best_product = product["Name"]



        print("\n🏆 BEST PRODUCT:",
              best_product)

        print("🚀 AI Decision: ADD PRODUCT TO STORE")

        print("\n✅ Product Hunting Completed")



# ===============================
# SYSTEM TEST
# ===============================

PRODUCT_AI = AI_Real_Product_Hunter_Agent()


PRODUCT_AI.add_product(
    "Car Phone Holder",
    95,
    30,
    90
)


PRODUCT_AI.add_product(
    "LED Cabinet Light",
    85,
    40,
    80
)


PRODUCT_AI.add_product(
    "Mini Vacuum Cleaner",
    80,
    50,
    75
)


PRODUCT_AI.find_best_product()