# ==================================================
# AI E-COMMERCE AUTOPILOT SYSTEM
# AI AUTOMATIC PRODUCT LISTING AGENT
# Code No: 102
# Version: 3.0
# ==================================================


class AI_Automatic_Product_Listing_Agent:

    def __init__(self):

        self.listings = []

        print("=" * 70)
        print("📝 AI AUTOMATIC PRODUCT LISTING AGENT")
        print("=" * 70)



    # ------------------------------------------------

    def create_listing(
        self,
        product,
        category,
        price
    ):

        title = (
            "Premium "
            + product
            + " | Best Quality Product"
        )


        description = (
            product
            +
            " is a high demand product "
            "designed for modern customers. "
            "Fast delivery, premium quality "
            "and excellent value."
        )


        keywords = [

            product,
            category,
            "best seller",
            "online shopping",
            "premium quality"

        ]


        self.listings.append({

            "Product": product,
            "Title": title,
            "Description": description,
            "Price": price,
            "Keywords": keywords

        })


        print(
            "✅ Listing Created:",
            product
        )



    # ------------------------------------------------

    def show_listing(self):

        print("\n🛒 PRODUCT LISTING REPORT")
        print("-" * 50)


        for item in self.listings:

            print("\n📦 Product:",
                  item["Product"])

            print("\n📝 Title:")
            print(item["Title"])


            print("\n📄 Description:")
            print(item["Description"])


            print("\n💰 Price: $",
                  item["Price"])


            print("\n🔍 SEO Keywords:")

            for word in item["Keywords"]:

                print("✅", word)


            print("-" * 50)



        print("\n🚀 Listing Status: READY FOR STORE")

        print("\n✅ Automatic Listing Completed")



# ===============================
# SYSTEM TEST
# ===============================

LISTING_AI = AI_Automatic_Product_Listing_Agent()


LISTING_AI.create_listing(
    "Car Phone Holder",
    "Car Accessories",
    18
)


LISTING_AI.show_listing()