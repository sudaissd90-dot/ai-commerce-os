# ==================================================
# AI E-COMMERCE AUTOPILOT SYSTEM
# AI COMPETITOR PRICE SCANNER AGENT
# Code No: 103
# Version: 3.0
# ==================================================


class AI_Competitor_Price_Scanner_Agent:

    def __init__(self):

        self.products = []

        print("=" * 70)
        print("💰 AI COMPETITOR PRICE SCANNER AGENT")
        print("=" * 70)



    # ------------------------------------------------

    def add_price_data(
        self,
        product,
        our_price,
        competitor_price
    ):

        self.products.append({

            "Product": product,
            "Our Price": our_price,
            "Competitor Price": competitor_price

        })


        print(
            "✅ Price Data Added:",
            product
        )



    # ------------------------------------------------

    def analyze_price(self):

        print("\n📊 PRICE ANALYSIS REPORT")
        print("-" * 50)


        for item in self.products:

            difference = (
                item["Competitor Price"]
                -
                item["Our Price"]
            )


            print("\n📦 Product:",
                  item["Product"])

            print("Our Price: $",
                  item["Our Price"])

            print("Competitor Price: $",
                  item["Competitor Price"])


            print("Price Difference: $",
                  difference)



            print("\n🤖 AI PRICE DECISION")


            if difference > 0:

                print("✅ Advantage: Lower Price")
                print("🚀 Strategy: Maintain Competitive Pricing")


            elif difference == 0:

                print("⚖️ Market Match")
                print("Strategy: Improve Value")


            else:

                print("⚠️ Price Higher")
                print("Strategy: Reduce Price")



            print("-" * 50)


        print("\n✅ Competitor Price Analysis Completed")



# ===============================
# SYSTEM TEST
# ===============================

PRICE_AI = AI_Competitor_Price_Scanner_Agent()


PRICE_AI.add_price_data(
    "Car Phone Holder",
    18,
    22
)


PRICE_AI.add_price_data(
    "LED Cabinet Light",
    15,
    17
)


PRICE_AI.analyze_price()