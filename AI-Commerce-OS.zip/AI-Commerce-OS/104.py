# ==================================================
# AI E-COMMERCE AUTOPILOT SYSTEM
# AI MARKETING CONTENT GENERATOR AGENT
# Code No: 104
# Version: 3.0
# ==================================================


class AI_Marketing_Content_Generator_Agent:

    def __init__(self):

        self.campaigns = []

        print("=" * 70)
        print("📢 AI MARKETING CONTENT GENERATOR AGENT")
        print("=" * 70)



    # ------------------------------------------------

    def create_campaign(
        self,
        product,
        audience,
        platform
    ):

        headline = (
            "🔥 Upgrade Your Life With "
            + product
        )


        caption = (
            "Discover the amazing "
            + product
            +
            ". High quality, smart design "
            "and perfect value for money."
        )


        strategy = (
            "Target "
            + audience
            +
            " through "
            + platform
            +
            " advertising"
        )


        self.campaigns.append({

            "Product": product,
            "Headline": headline,
            "Caption": caption,
            "Strategy": strategy

        })


        print(
            "✅ Campaign Created:",
            product
        )



    # ------------------------------------------------

    def show_campaign(self):

        print("\n📊 MARKETING CAMPAIGN REPORT")
        print("-" * 50)


        for campaign in self.campaigns:

            print("\n📦 Product:",
                  campaign["Product"])


            print("\n🔥 Headline:")
            print(campaign["Headline"])


            print("\n📝 Caption:")
            print(campaign["Caption"])


            print("\n🎯 Strategy:")
            print(campaign["Strategy"])


            print("-" * 50)



        print("\n🚀 Campaign Status: READY TO LAUNCH")

        print("\n✅ Marketing Content Completed")



# ===============================
# SYSTEM TEST
# ===============================

MARKETING_AI = AI_Marketing_Content_Generator_Agent()


MARKETING_AI.create_campaign(
    "Car Phone Holder",
    "Car Owners Age 20-50",
    "TikTok + Facebook Ads"
)


MARKETING_AI.show_campaign()