# ==================================================
# AI E-COMMERCE AUTOPILOT SYSTEM
# AI CUSTOMER SUPPORT AUTOMATION AGENT
# Code No: 105
# Version: 3.0
# ==================================================


class AI_Customer_Support_Automation_Agent:

    def __init__(self):

        self.customer_queries = []

        print("=" * 70)
        print("🤖 AI CUSTOMER SUPPORT AUTOMATION AGENT")
        print("=" * 70)



    # ------------------------------------------------

    def add_customer_query(
        self,
        customer,
        question
    ):

        self.customer_queries.append({

            "Customer": customer,
            "Question": question

        })


        print(
            "✅ Customer Query Added:",
            customer
        )



    # ------------------------------------------------

    def generate_response(self):

        print("\n📩 CUSTOMER SUPPORT REPORT")
        print("-" * 50)


        for query in self.customer_queries:

            print("\n👤 Customer:",
                  query["Customer"])

            print("❓ Question:",
                  query["Question"])


            question = query["Question"].lower()


            print("\n🤖 AI Response:")


            if "delivery" in question:

                print(
                    "Your order will be delivered "
                    "within estimated delivery time."
                )


            elif "return" in question:

                print(
                    "You can request a return "
                    "according to our return policy."
                )


            elif "price" in question:

                print(
                    "Our prices are competitive "
                    "with premium quality."
                )


            else:

                print(
                    "Thank you for contacting us. "
                    "Our team will assist you."
                )


            print("-" * 50)



        print("\n🚀 Support Status: 24/7 ACTIVE")

        print("\n✅ Customer Support Automation Completed")



# ===============================
# SYSTEM TEST
# ===============================

SUPPORT_AI = AI_Customer_Support_Automation_Agent()


SUPPORT_AI.add_customer_query(
    "Ali",
    "When will my delivery arrive?"
)


SUPPORT_AI.add_customer_query(
    "Ahmed",
    "Can I return this product?"
)


SUPPORT_AI.add_customer_query(
    "Usman",
    "What is the price?"
)


SUPPORT_AI.generate_response()