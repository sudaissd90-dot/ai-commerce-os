# ==================================================
# AI E-COMMERCE AUTOPILOT SYSTEM
# AI INVENTORY AUTO MANAGEMENT AGENT
# Code No: 106
# Version: 3.0
# ==================================================


class AI_Inventory_Auto_Management_Agent:

    def __init__(self):

        self.inventory = []

        print("=" * 70)
        print("📦 AI INVENTORY AUTO MANAGEMENT AGENT")
        print("=" * 70)



    # ------------------------------------------------

    def add_product_stock(
        self,
        product,
        stock,
        minimum_stock
    ):

        self.inventory.append({

            "Product": product,
            "Stock": stock,
            "Minimum": minimum_stock

        })


        print(
            "✅ Inventory Added:",
            product
        )



    # ------------------------------------------------

    def analyze_inventory(self):

        print("\n📊 INVENTORY REPORT")
        print("-" * 50)


        for item in self.inventory:

            print("\n📦 Product:",
                  item["Product"])

            print("Current Stock:",
                  item["Stock"])

            print("Minimum Stock:",
                  item["Minimum"])



            print("\n🤖 AI INVENTORY DECISION")


            if item["Stock"] <= item["Minimum"]:

                print("⚠️ Status: LOW STOCK")
                print("🚚 Action: Order New Inventory")


            else:

                print("✅ Status: STOCK AVAILABLE")
                print("📦 Action: Continue Selling")



            print("-" * 50)



        print("\n🚀 Inventory System Status: ACTIVE")

        print("\n✅ Inventory Management Completed")



# ===============================
# SYSTEM TEST
# ===============================

INVENTORY_AI = AI_Inventory_Auto_Management_Agent()


INVENTORY_AI.add_product_stock(
    "Car Phone Holder",
    120,
    30
)


INVENTORY_AI.add_product_stock(
    "LED Cabinet Light",
    25,
    30
)


INVENTORY_AI.add_product_stock(
    "Mini Vacuum Cleaner",
    80,
    20
)


INVENTORY_AI.analyze_inventory()