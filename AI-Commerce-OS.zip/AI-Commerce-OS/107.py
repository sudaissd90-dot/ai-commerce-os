# ==================================================
# AI E-COMMERCE AUTOPILOT SYSTEM
# AI ORDER PROCESSING AUTOMATION AGENT
# Code No: 107
# Version: 3.0
# ==================================================


class AI_Order_Processing_Automation_Agent:

    def __init__(self):

        self.orders = []

        print("=" * 70)
        print("📦 AI ORDER PROCESSING AUTOMATION AGENT")
        print("=" * 70)



    # ------------------------------------------------

    def add_order(
        self,
        customer,
        product,
        quantity
    ):

        self.orders.append({

            "Customer": customer,
            "Product": product,
            "Quantity": quantity,
            "Status": "New Order"

        })


        print(
            "✅ Order Received:",
            customer
        )



    # ------------------------------------------------

    def process_orders(self):

        print("\n📊 ORDER PROCESSING REPORT")
        print("-" * 50)


        for order in self.orders:

            print("\n👤 Customer:",
                  order["Customer"])

            print("📦 Product:",
                  order["Product"])

            print("🔢 Quantity:",
                  order["Quantity"])


            order["Status"] = "Processing"


            print("⚙️ Status:",
                  order["Status"])


            order["Status"] = "Shipped"


            print("🚚 Status:",
                  order["Status"])


            order["Status"] = "Completed"


            print("✅ Status:",
                  order["Status"])


            print("-" * 50)



        print("\n🚀 Order System Status: ACTIVE")

        print("\n✅ Order Processing Completed")



# ===============================
# SYSTEM TEST
# ===============================

ORDER_AI = AI_Order_Processing_Automation_Agent()


ORDER_AI.add_order(
    "Ali",
    "Car Phone Holder",
    2
)


ORDER_AI.add_order(
    "Ahmed",
    "LED Cabinet Light",
    1
)


ORDER_AI.process_orders()