# ==================================================
# AI E-COMMERCE AUTOPILOT SYSTEM
# AI SALES ANALYTICS AGENT
# Code No: 108
# Version: 3.0
# ==================================================


class AI_Sales_Analytics_Agent:

    def __init__(self):

        self.sales = []

        print("=" * 70)
        print("📈 AI SALES ANALYTICS AGENT")
        print("=" * 70)



    # ------------------------------------------------

    def add_sale(
        self,
        product,
        quantity,
        price
    ):

        self.sales.append({

            "Product": product,
            "Quantity": quantity,
            "Price": price

        })


        print(
            "✅ Sale Added:",
            product
        )



    # ------------------------------------------------

    def analyze_sales(self):

        print("\n📊 SALES ANALYTICS REPORT")
        print("-" * 50)


        total_revenue = 0
        product_sales = {}


        for sale in self.sales:

            revenue = (
                sale["Quantity"]
                *
                sale["Price"]
            )


            total_revenue += revenue


            if sale["Product"] in product_sales:

                product_sales[sale["Product"]] += sale["Quantity"]

            else:

                product_sales[sale["Product"]] = sale["Quantity"]



            print("\n📦 Product:",
                  sale["Product"])

            print("Quantity:",
                  sale["Quantity"])

            print("Revenue: $",
                  revenue)



        best_product = max(
            product_sales,
            key=product_sales.get
        )


        print("\n💰 Total Revenue: $",
              total_revenue)


        print("🏆 Best Selling Product:",
              best_product)



        print("\n🤖 AI SALES DECISION")
        print("-" * 50)


        if total_revenue >= 100:

            print("🚀 Status: STRONG SALES")
            print("Action: Increase Marketing")


        else:

            print("⚠️ Status: NEEDS GROWTH")
            print("Action: Improve Campaigns")



        print("\n✅ Sales Analytics Completed")



# ===============================
# SYSTEM TEST
# ===============================

SALES_AI = AI_Sales_Analytics_Agent()


SALES_AI.add_sale(
    "Car Phone Holder",
    10,
    18
)


SALES_AI.add_sale(
    "LED Cabinet Light",
    5,
    15
)


SALES_AI.add_sale(
    "Mini Vacuum Cleaner",
    3,
    25
)


SALES_AI.analyze_sales()