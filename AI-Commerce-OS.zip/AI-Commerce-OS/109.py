# ==================================================
# AI E-COMMERCE AUTOPILOT SYSTEM
# AI PROFIT OPTIMIZATION AGENT
# Code No: 109
# Version: 3.0
# ==================================================


class AI_Profit_Optimization_Agent:

    def __init__(self):

        self.products = []

        print("=" * 70)
        print("💰 AI PROFIT OPTIMIZATION AGENT")
        print("=" * 70)



    # ------------------------------------------------

    def add_product(
        self,
        product,
        cost,
        selling_price,
        sales
    ):

        self.products.append({

            "Product": product,
            "Cost": cost,
            "Price": selling_price,
            "Sales": sales

        })


        print(
            "✅ Product Added:",
            product
        )



    # ------------------------------------------------

    def analyze_profit(self):

        print("\n📊 PROFIT OPTIMIZATION REPORT")
        print("-" * 50)


        highest_profit_product = ""
        highest_profit = 0


        for item in self.products:

            profit_per_unit = (
                item["Price"]
                -
                item["Cost"]
            )


            total_profit = (
                profit_per_unit
                *
                item["Sales"]
            )


            print("\n📦 Product:",
                  item["Product"])

            print("Cost: $",
                  item["Cost"])

            print("Selling Price: $",
                  item["Price"])

            print("Total Profit: $",
                  total_profit)


            if total_profit > highest_profit:

                highest_profit = total_profit
                highest_profit_product = item["Product"]



        print("\n🏆 Most Profitable Product:",
              highest_profit_product)


        print("\n🤖 AI PROFIT DECISION")
        print("-" * 50)


        print("🚀 Action: Scale High Profit Products")
        print("💰 Strategy: Improve Profit Margins")


        print("\n✅ Profit Optimization Completed")



# ===============================
# SYSTEM TEST
# ===============================

PROFIT_AI = AI_Profit_Optimization_Agent()


PROFIT_AI.add_product(
    "Car Phone Holder",
    8,
    18,
    100
)


PROFIT_AI.add_product(
    "LED Cabinet Light",
    6,
    15,
    80
)


PROFIT_AI.add_product(
    "Mini Vacuum Cleaner",
    12,
    25,
    50
)


PROFIT_AI.analyze_profit()