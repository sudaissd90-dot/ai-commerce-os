# ==================================================
# AI E-COMMERCE AUTOPILOT SYSTEM
# AI CUSTOMER BEHAVIOR PREDICTION AGENT
# Code No: 113
# Version: 3.0
# ==================================================


class AI_Customer_Behavior_Prediction_Agent:

    def __init__(self):

        self.customers = []

        print("=" * 70)
        print("🧠 AI CUSTOMER BEHAVIOR PREDICTION AGENT")
        print("=" * 70)



    # ------------------------------------------------

    def add_customer(
        self,
        name,
        purchases,
        spending,
        visits
    ):

        self.customers.append({

            "Name": name,
            "Purchases": purchases,
            "Spending": spending,
            "Visits": visits

        })


        print(
            "✅ Customer Added:",
            name
        )



    # ------------------------------------------------

    def predict_behavior(self):

        print("\n📊 CUSTOMER BEHAVIOR REPORT")
        print("-" * 50)


        for customer in self.customers:

            score = (
                customer["Purchases"]
                +
                customer["Visits"]
                +
                (customer["Spending"] / 10)
            )


            print("\n👤 Customer:",
                  customer["Name"])

            print("Purchases:",
                  customer["Purchases"])

            print("Spending: $",
                  customer["Spending"])

            print("Visits:",
                  customer["Visits"])


            print("🧠 AI Customer Score:",
                  round(score,2))


            print("\n🤖 AI Prediction:")


            if score >= 80:

                print("⭐ Loyal Customer")
                print("Action: Send Premium Offers")


            elif score >= 40:

                print("✅ Potential Customer")
                print("Action: Send Promotions")


            else:

                print("⚠️ Low Engagement")
                print("Action: Re-engagement Campaign")



            print("-" * 50)



        print("\n🚀 Customer Intelligence Status: ACTIVE")

        print("\n✅ Customer Behavior Prediction Completed")



# ===============================
# SYSTEM TEST
# ===============================

CUSTOMER_AI = AI_Customer_Behavior_Prediction_Agent()


CUSTOMER_AI.add_customer(
    "Ali",
    15,
    500,
    60
)


CUSTOMER_AI.add_customer(
    "Ahmed",
    5,
    150,
    25
)


CUSTOMER_AI.add_customer(
    "Usman",
    20,
    900,
    70
)


CUSTOMER_AI.predict_behavior()