# ==================================================
# AI E-COMMERCE AUTOPILOT SYSTEM
# AI SMART RECOMMENDATION ENGINE
# Code No: 114
# Version: 3.0
# ==================================================


class AI_Smart_Recommendation_Engine:

    def __init__(self):

        self.customers = []

        print("=" * 70)
        print("🛒 AI SMART RECOMMENDATION ENGINE")
        print("=" * 70)



    # ------------------------------------------------

    def add_customer_interest(
        self,
        customer,
        category,
        previous_product
    ):

        self.customers.append({

            "Customer": customer,
            "Category": category,
            "Previous Product": previous_product

        })


        print(
            "✅ Customer Added:",
            customer
        )



    # ------------------------------------------------

    def generate_recommendations(self):

        print("\n📊 RECOMMENDATION REPORT")
        print("-" * 50)


        for customer in self.customers:

            print("\n👤 Customer:",
                  customer["Customer"])

            print("Interest:",
                  customer["Category"])

            print("Previous Purchase:",
                  customer["Previous Product"])


            print("\n🤖 AI Recommendation:")


            if customer["Category"] == "Car Accessories":

                print("🚗 Recommend:")
                print("✅ Car Phone Holder")
                print("✅ Car Charger")
                print("✅ Dashboard Organizer")


            elif customer["Category"] == "Home":

                print("🏠 Recommend:")
                print("✅ LED Cabinet Light")
                print("✅ Smart Home Devices")


            else:

                print("⭐ Recommend:")
                print("✅ Trending Products")



            print("-" * 50)



        print("\n🚀 Recommendation Engine Status: ACTIVE")

        print("\n✅ Smart Recommendations Completed")



# ===============================
# SYSTEM TEST
# ===============================

RECOMMEND_AI = AI_Smart_Recommendation_Engine()


RECOMMEND_AI.add_customer_interest(
    "Ali",
    "Car Accessories",
    "Car Phone Holder"
)


RECOMMEND_AI.add_customer_interest(
    "Ahmed",
    "Home",
    "LED Cabinet Light"
)


RECOMMEND_AI.generate_recommendations()