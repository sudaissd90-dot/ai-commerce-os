# ==================================================
# AI E-COMMERCE AUTOPILOT SYSTEM
# AI DYNAMIC PRICING AGENT
# Code No: 115
# Version: 3.0
# ==================================================


class AI_Dynamic_Pricing_Agent:

    def __init__(self):

        self.products = []

        print("=" * 70)
        print("💰 AI DYNAMIC PRICING AGENT")
        print("=" * 70)



    # ------------------------------------------------

    def add_product(
        self,
        product,
        current_price,
        demand_score,
        competitor_price
    ):

        self.products.append({

            "Product": product,
            "Current Price": current_price,
            "Demand": demand_score,
            "Competitor": competitor_price

        })


        print(
            "✅ Product Added:",
            product
        )



    # ------------------------------------------------

    def optimize_price(self):

        print("\n📊 DYNAMIC PRICING REPORT")
        print("-" * 50)


        for product in self.products:

            new_price = product["Current Price"]


            print("\n📦 Product:",
                  product["Product"])

            print("Current Price: $",
                  product["Current Price"])

            print("Demand Score:",
                  product["Demand"])

            print("Competitor Price: $",
                  product["Competitor"])



            if product["Demand"] >= 90:

                new_price += 2

                decision = "Increase Price - High Demand"


            elif product["Demand"] <= 50:

                new_price -= 2

                decision = "Reduce Price - Increase Sales"


            else:

                decision = "Maintain Current Price"



            print("\n🤖 AI Pricing Decision:")
            print(decision)

            print("Recommended Price: $",
                  new_price)


            print("-" * 50)



        print("\n🚀 Dynamic Pricing Status: ACTIVE")

        print("\n✅ Pricing Optimization Completed")



# ===============================
# SYSTEM TEST
# ===============================

PRICE_AI = AI_Dynamic_Pricing_Agent()


PRICE_AI.add_product(
    "Car Phone Holder",
    18,
    95,
    22
)


PRICE_AI.add_product(
    "LED Cabinet Light",
    15,
    45,
    17
)


PRICE_AI.add_product(
    "Mini Vacuum Cleaner",
    25,
    70,
    30
)


PRICE_AI.optimize_price()