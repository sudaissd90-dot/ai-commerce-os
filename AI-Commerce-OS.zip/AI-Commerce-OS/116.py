# ==================================================
# AI E-COMMERCE AUTOPILOT SYSTEM
# AI SUPPLIER SELECTION AGENT
# Code No: 116
# Version: 3.0
# ==================================================


class AI_Supplier_Selection_Agent:

    def __init__(self):

        self.suppliers = []

        print("=" * 70)
        print("📦 AI SUPPLIER SELECTION AGENT")
        print("=" * 70)



    # ------------------------------------------------

    def add_supplier(
        self,
        name,
        product_cost,
        quality_score,
        delivery_score
    ):

        self.suppliers.append({

            "Supplier": name,
            "Cost": product_cost,
            "Quality": quality_score,
            "Delivery": delivery_score

        })


        print(
            "✅ Supplier Added:",
            name
        )



    # ------------------------------------------------

    def analyze_suppliers(self):

        print("\n📊 SUPPLIER ANALYSIS REPORT")
        print("-" * 50)


        best_supplier = ""
        best_score = 0


        for supplier in self.suppliers:

            score = (
                supplier["Quality"]
                +
                supplier["Delivery"]
                -
                supplier["Cost"]
            )


            print("\n🏢 Supplier:",
                  supplier["Supplier"])

            print("💰 Product Cost: $",
                  supplier["Cost"])

            print("⭐ Quality Score:",
                  supplier["Quality"])

            print("🚚 Delivery Score:",
                  supplier["Delivery"])

            print("🧠 AI Supplier Score:",
                  score)



            if score > best_score:

                best_score = score
                best_supplier = supplier["Supplier"]



        print("\n🏆 BEST SUPPLIER:",
              best_supplier)


        print("\n🤖 AI SUPPLIER DECISION")
        print("-" * 50)

        print("🚀 Action: Select Best Supplier")
        print("📦 Strategy: Optimize Cost + Quality")


        print("\n✅ Supplier Selection Completed")



# ===============================
# SYSTEM TEST
# ===============================

SUPPLIER_AI = AI_Supplier_Selection_Agent()


SUPPLIER_AI.add_supplier(
    "Supplier A",
    8,
    95,
    90
)


SUPPLIER_AI.add_supplier(
    "Supplier B",
    6,
    80,
    85
)


SUPPLIER_AI.add_supplier(
    "Supplier C",
    10,
    98,
    95
)


SUPPLIER_AI.analyze_suppliers()