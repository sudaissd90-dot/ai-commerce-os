# ==================================================
# AI E-COMMERCE AUTOPILOT SYSTEM
# AI FRAUD DETECTION & RISK AGENT
# Code No: 117
# Version: 3.0
# ==================================================


class AI_Fraud_Detection_Risk_Agent:

    def __init__(self):

        self.orders = []

        print("=" * 70)
        print("🛡️ AI FRAUD DETECTION & RISK AGENT")
        print("=" * 70)



    # ------------------------------------------------

    def add_order(
        self,
        customer,
        amount,
        payment_score,
        location_score
    ):

        self.orders.append({

            "Customer": customer,
            "Amount": amount,
            "Payment": payment_score,
            "Location": location_score

        })


        print(
            "✅ Order Analyzed:",
            customer
        )



    # ------------------------------------------------

    def detect_fraud(self):

        print("\n📊 FRAUD RISK REPORT")
        print("-" * 50)


        for order in self.orders:

            risk = (
                100
                -
                (
                    order["Payment"]
                    +
                    order["Location"]
                )
                /2
            )


            print("\n👤 Customer:",
                  order["Customer"])

            print("💰 Order Amount: $",
                  order["Amount"])

            print("💳 Payment Score:",
                  order["Payment"])

            print("🌍 Location Score:",
                  order["Location"])

            print("⚠️ Risk Score:",
                  round(risk,2))



            print("\n🤖 AI SECURITY DECISION")


            if risk >= 50:

                print("🚨 Status: HIGH RISK")
                print("Action: Hold Order For Review")


            elif risk >= 25:

                print("⚠️ Status: MEDIUM RISK")
                print("Action: Extra Verification")


            else:

                print("✅ Status: SAFE ORDER")
                print("Action: Process Order")



            print("-" * 50)



        print("\n🛡️ Fraud Protection Status: ACTIVE")

        print("\n✅ Fraud Detection Completed")



# ===============================
# SYSTEM TEST
# ===============================

FRAUD_AI = AI_Fraud_Detection_Risk_Agent()


FRAUD_AI.add_order(
    "Ali",
    120,
    95,
    90
)


FRAUD_AI.add_order(
    "Ahmed",
    800,
    40,
    50
)


FRAUD_AI.add_order(
    "Usman",
    250,
    85,
    80
)


FRAUD_AI.detect_fraud()