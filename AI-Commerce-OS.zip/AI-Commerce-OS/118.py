# ==================================================
# AI E-COMMERCE AUTOPILOT SYSTEM
# AI CUSTOMER RETENTION & LOYALTY AGENT
# Code No: 118
# Version: 3.0
# ==================================================


class AI_Customer_Retention_Loyalty_Agent:

    def __init__(self):

        self.customers = []

        print("=" * 70)
        print("⭐ AI CUSTOMER RETENTION & LOYALTY AGENT")
        print("=" * 70)



    # ------------------------------------------------

    def add_customer(
        self,
        name,
        purchases,
        total_spending,
        reviews
    ):

        self.customers.append({

            "Name": name,
            "Purchases": purchases,
            "Spending": total_spending,
            "Reviews": reviews

        })


        print(
            "✅ Customer Added:",
            name
        )



    # ------------------------------------------------

    def analyze_loyalty(self):

        print("\n📊 CUSTOMER LOYALTY REPORT")
        print("-" * 50)


        for customer in self.customers:

            loyalty_score = (

                customer["Purchases"]
                +
                (customer["Spending"] / 10)
                +
                customer["Reviews"]

            )


            print("\n👤 Customer:",
                  customer["Name"])

            print("🛒 Purchases:",
                  customer["Purchases"])

            print("💰 Spending: $",
                  customer["Spending"])

            print("⭐ Reviews:",
                  customer["Reviews"])


            print("🧠 Loyalty Score:",
                  round(loyalty_score,2))


            print("\n🤖 AI Loyalty Decision")


            if loyalty_score >= 100:

                print("🏆 VIP Customer")
                print("🎁 Action: Premium Rewards + Special Offers")


            elif loyalty_score >= 50:

                print("⭐ Loyal Customer")
                print("🎁 Action: Discount Offers")


            else:

                print("⚠️ New Customer")
                print("📩 Action: Engagement Campaign")



            print("-" * 50)



        print("\n🚀 Loyalty System Status: ACTIVE")

        print("\n✅ Customer Retention Completed")



# ===============================
# SYSTEM TEST
# ===============================

LOYALTY_AI = AI_Customer_Retention_Loyalty_Agent()


LOYALTY_AI.add_customer(
    "Ali",
    15,
    700,
    10
)


LOYALTY_AI.add_customer(
    "Ahmed",
    4,
    120,
    5
)


LOYALTY_AI.add_customer(
    "Usman",
    20,
    1000,
    15
)


LOYALTY_AI.analyze_loyalty()