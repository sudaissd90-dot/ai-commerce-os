# ==================================================
# AI E-COMMERCE AUTOPILOT SYSTEM
# AI GLOBAL SALES EXPANSION AGENT
# Code No: 119
# Version: 3.0
# ==================================================


class AI_Global_Sales_Expansion_Agent:

    def __init__(self):

        self.markets = []

        print("=" * 70)
        print("🌍 AI GLOBAL SALES EXPANSION AGENT")
        print("=" * 70)



    # ------------------------------------------------

    def add_market(
        self,
        country,
        demand_score,
        competition_score,
        revenue_potential
    ):

        self.markets.append({

            "Country": country,
            "Demand": demand_score,
            "Competition": competition_score,
            "Revenue": revenue_potential

        })


        print(
            "✅ Market Added:",
            country
        )



    # ------------------------------------------------

    def analyze_markets(self):

        print("\n📊 GLOBAL MARKET ANALYSIS")
        print("-" * 50)


        best_market = ""
        best_score = 0


        for market in self.markets:

            score = (

                market["Demand"]
                +
                market["Revenue"]
                -
                market["Competition"]

            )


            print("\n🌍 Country:",
                  market["Country"])

            print("📈 Demand Score:",
                  market["Demand"])

            print("⚔️ Competition Score:",
                  market["Competition"])

            print("💰 Revenue Potential:",
                  market["Revenue"])

            print("🧠 AI Market Score:",
                  score)



            if score > best_score:

                best_score = score
                best_market = market["Country"]



        print("\n🏆 BEST EXPANSION MARKET:",
              best_market)


        print("\n🤖 AI GLOBAL DECISION")
        print("-" * 50)

        print("🚀 Action: Enter High Potential Market")
        print("🌍 Strategy: Expand Global Operations")


        print("\n✅ Global Expansion Analysis Completed")



# ===============================
# SYSTEM TEST
# ===============================

GLOBAL_AI = AI_Global_Sales_Expansion_Agent()


GLOBAL_AI.add_market(
    "USA",
    95,
    40,
    100
)


GLOBAL_AI.add_market(
    "UK",
    85,
    35,
    80
)


GLOBAL_AI.add_market(
    "Saudi Arabia",
    88,
    30,
    85
)


GLOBAL_AI.analyze_markets()