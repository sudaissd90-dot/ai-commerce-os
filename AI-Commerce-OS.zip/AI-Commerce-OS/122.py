# ==================================================
# AI E-COMMERCE AUTOPILOT SYSTEM
# AI PRODUCT AUTO LISTING ENGINE
# Code No: 122
# Version: 1.0
# ==================================================


class AI_Product_Auto_Listing_Engine:

    def __init__(self):

        self.listings = []

        print("=" * 70)
        print("🛒 AI PRODUCT AUTO LISTING ENGINE")
        print("=" * 70)



    # ------------------------------------------------

    def create_listing(
        self,
        product,
        category,
        cost,
        selling_price
    ):

        title = (
            "Premium "
            + product
            + " | Best Quality Product"
        )


        description = (
            product
            + " is a high demand "
            + category
            + " product. "
            "Designed for modern customers "
            "with premium quality and great value."
        )


        keywords = [

            product,
            category,
            "best seller",
            "online shopping",
            "premium quality"

        ]


        self.listings.append({

            "Product": product,
            "Title": title,
            "Description": description,
            "Price": selling_price,
            "Keywords": keywords

        })


        print(
            "✅ Listing Created:",
            product
        )



    # ------------------------------------------------

    def show_listings(self):

        print("\n📊 AUTO LISTING REPORT")
        print("-" * 50)


        for item in self.listings:

            print("\n📦 Product:",
                  item["Product"])

            print("\n📝 Title:")
            print(item["Title"])


            print("\n📄 Description:")
            print(item["Description"])


            print("\n💰 Selling Price: $",
                  item["Price"])


            print("\n🔍 SEO Keywords:")

            for word in item["Keywords"]:

                print("✅", word)


            print("-" * 50)



        print("\n🚀 Listing System Status: ACTIVE")

        print("\n✅ Auto Listing Completed")



# ===============================
# SYSTEM TEST
# ===============================


LISTING_AI = AI_Product_Auto_Listing_Engine()


LISTING_AI.create_listing(
    "Car Phone Holder",
    "Car Accessories",
    8,
    18
)


LISTING_AI.create_listing(
    "LED Cabinet Light",
    "Home Gadgets",
    6,
    15
)


LISTING_AI.show_listings()