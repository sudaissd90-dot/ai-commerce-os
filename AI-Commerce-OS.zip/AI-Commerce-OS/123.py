# ==================================================
# AI E-COMMERCE AUTOPILOT SYSTEM
# AI ORDER SYNCHRONIZATION ENGINE
# Code No: 123
# Version: 1.0
# ==================================================


class AI_Order_Synchronization_Engine:

    def __init__(self):

        self.orders = []

        print("=" * 70)
        print("📦 AI ORDER SYNCHRONIZATION ENGINE")
        print("=" * 70)



    # ------------------------------------------------

    def receive_order(
        self,
        customer,
        product,
        quantity,
        payment_status
    ):

        self.orders.append({

            "Customer": customer,
            "Product": product,
            "Quantity": quantity,
            "Payment": payment_status,
            "Status": "Received"

        })


        print(
            "✅ Order Received:",
            customer
        )



    # ------------------------------------------------

    def process_orders(self):

        print("\n📊 ORDER SYNCHRONIZATION REPORT")
        print("-" * 50)


        for order in self.orders:


            print("\n👤 Customer:",
                  order["Customer"])

            print("📦 Product:",
                  order["Product"])

            print("🔢 Quantity:",
                  order["Quantity"])

            print("💳 Payment:",
                  order["Payment"])



            if order["Payment"] == "Completed":

                order["Status"] = "Processing"

                print("⚙️ Status: Processing")


                order["Status"] = "Shipped"

                print("🚚 Status: Shipped")


                order["Status"] = "Completed"

                print("✅ Status: Completed")


            else:

                order["Status"] = "Payment Pending"

                print("⚠️ Status: Payment Pending")



            print("-" * 50)



        print("\n🔄 Order Sync Status: ACTIVE")

        print("\n✅ Order Synchronization Completed")



# ===============================
# SYSTEM TEST
# ===============================


ORDER_AI = AI_Order_Synchronization_Engine()


ORDER_AI.receive_order(
    "Ali",
    "Car Phone Holder",
    2,
    "Completed"
)


ORDER_AI.receive_order(
    "Ahmed",
    "LED Cabinet Light",
    1,
    "Completed"
)


ORDER_AI.process_orders()