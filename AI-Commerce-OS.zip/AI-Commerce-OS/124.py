# ==================================================
# AI E-COMMERCE AUTOPILOT SYSTEM
# AI INVENTORY SYNCHRONIZATION ENGINE
# Code No: 124
# Version: 1.0
# ==================================================


class AI_Inventory_Synchronization_Engine:

    def __init__(self):

        self.inventory = []

        print("=" * 70)
        print("📦 AI INVENTORY SYNCHRONIZATION ENGINE")
        print("=" * 70)



    # ------------------------------------------------

    def add_inventory(
        self,
        product,
        stock,
        sold,
        minimum_stock
    ):

        self.inventory.append({

            "Product": product,
            "Stock": stock,
            "Sold": sold,
            "Minimum": minimum_stock

        })


        print(
            "✅ Inventory Added:",
            product
        )



    # ------------------------------------------------

    def sync_inventory(self):

        print("\n📊 INVENTORY SYNC REPORT")
        print("-" * 50)


        for item in self.inventory:


            remaining = (
                item["Stock"]
                -
                item["Sold"]
            )


            print("\n📦 Product:",
                  item["Product"])

            print("Initial Stock:",
                  item["Stock"])

            print("Sold Quantity:",
                  item["Sold"])

            print("Remaining Stock:",
                  remaining)



            print("\n🤖 AI Inventory Decision")


            if remaining <= item["Minimum"]:

                print("⚠️ Status: LOW STOCK")
                print("🚚 Action: Auto Restock Required")


            else:

                print("✅ Status: STOCK AVAILABLE")
                print("📦 Action: Continue Selling")



            print("-" * 50)



        print("\n🔄 Inventory Sync Status: ACTIVE")

        print("\n✅ Inventory Synchronization Completed")



# ===============================
# SYSTEM TEST
# ===============================


INVENTORY_AI = AI_Inventory_Synchronization_Engine()


INVENTORY_AI.add_inventory(
    "Car Phone Holder",
    120,
    20,
    30
)


INVENTORY_AI.add_inventory(
    "LED Cabinet Light",
    50,
    35,
    30
)


INVENTORY_AI.add_inventory(
    "Mini Vacuum Cleaner",
    80,
    15,
    20
)


INVENTORY_AI.sync_inventory()