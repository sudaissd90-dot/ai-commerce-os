# ==================================================
# AI E-COMMERCE AUTOPILOT SYSTEM
# AI AUTOMATED SUPPLIER REORDER ENGINE
# Code No: 125
# Version: 1.0
# ==================================================


class AI_Automated_Supplier_Reorder_Engine:

    def __init__(self):

        self.products = []

        print("=" * 70)
        print("📦 AI AUTOMATED SUPPLIER REORDER ENGINE")
        print("=" * 70)



    # ------------------------------------------------

    def add_product(
        self,
        product,
        current_stock,
        minimum_stock,
        supplier,
        cost
    ):

        self.products.append({

            "Product": product,
            "Stock": current_stock,
            "Minimum": minimum_stock,
            "Supplier": supplier,
            "Cost": cost

        })


        print(
            "✅ Product Added:",
            product
        )



    # ------------------------------------------------

    def analyze_reorder(self):

        print("\n📊 REORDER ANALYSIS REPORT")
        print("-" * 50)


        for item in self.products:


            print("\n📦 Product:",
                  item["Product"])

            print("Current Stock:",
                  item["Stock"])

            print("Minimum Stock:",
                  item["Minimum"])

            print("🏢 Supplier:",
                  item["Supplier"])



            if item["Stock"] <= item["Minimum"]:

                reorder_quantity = (
                    item["Minimum"] * 3
                )


                total_cost = (
                    reorder_quantity
                    *
                    item["Cost"]
                )


                print("\n⚠️ Status: REORDER REQUIRED")

                print("📦 Reorder Quantity:",
                      reorder_quantity)

                print("💰 Purchase Cost: $",
                      total_cost)


                print("🚚 Action: Send Supplier Order")



            else:

                print("\n✅ Status: STOCK OK")

                print("📦 Action: No Reorder Needed")



            print("-" * 50)



        print("\n🤖 Supplier Automation Status: ACTIVE")

        print("\n✅ Automated Reorder Completed")



# ===============================
# SYSTEM TEST
# ===============================


REORDER_AI = AI_Automated_Supplier_Reorder_Engine()


REORDER_AI.add_product(
    "Car Phone Holder",
    100,
    30,
    "Supplier A",
    8
)


REORDER_AI.add_product(
    "LED Cabinet Light",
    15,
    30,
    "Supplier B",
    6
)


REORDER_AI.add_product(
    "Mini Vacuum Cleaner",
    65,
    20,
    "Supplier C",
    12
)


REORDER_AI.analyze_reorder()