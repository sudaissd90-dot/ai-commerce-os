# ==================================================
# AI E-COMMERCE AUTOPILOT SYSTEM
# AI SALES FORECASTING ENGINE
# Code No: 126
# Version: 1.0
# ==================================================


class AI_Sales_Forecasting_Engine:

    def __init__(self):

        self.products = []

        print("=" * 70)
        print("📈 AI SALES FORECASTING ENGINE")
        print("=" * 70)



    # ------------------------------------------------

    def add_product(
        self,
        product,
        previous_sales,
        growth_rate,
        demand_score
    ):

        self.products.append({

            "Product": product,
            "Sales": previous_sales,
            "Growth": growth_rate,
            "Demand": demand_score

        })


        print(
            "✅ Sales Data Added:",
            product
        )



    # ------------------------------------------------

    def forecast_sales(self):

        print("\n📊 SALES FORECAST REPORT")
        print("-" * 50)


        for item in self.products:


            forecast = (
                item["Sales"]
                +
                (
                    item["Sales"]
                    *
                    item["Growth"]
                    /
                    100
                )
            )


            print("\n📦 Product:",
                  item["Product"])

            print("Previous Sales:",
                  item["Sales"])


            print("Growth Rate:",
                  item["Growth"],
                  "%")


            print("📈 Forecast Sales:",
                  int(forecast))


            print("🔥 Demand Score:",
                  item["Demand"])



            print("\n🤖 AI Sales Decision")


            if item["Demand"] >= 90:

                print("🚀 High Demand Product")
                print("Action: Increase Inventory")


            elif item["Demand"] >= 70:

                print("⭐ Growing Product")
                print("Action: Maintain Stock")


            else:

                print("⚠️ Low Demand")
                print("Action: Review Strategy")



            print("-" * 50)



        print("\n📈 Forecast System Status: ACTIVE")

        print("\n✅ Sales Forecast Completed")



# ===============================
# SYSTEM TEST
# ===============================


FORECAST_AI = AI_Sales_Forecasting_Engine()


FORECAST_AI.add_product(
    "Car Phone Holder",
    100,
    25,
    95
)


FORECAST_AI.add_product(
    "LED Cabinet Light",
    80,
    15,
    75
)


FORECAST_AI.add_product(
    "Mini Vacuum Cleaner",
    60,
    10,
    70
)


FORECAST_AI.forecast_sales()