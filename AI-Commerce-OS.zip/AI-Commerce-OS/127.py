# ==================================================
# AI E-COMMERCE AUTOPILOT SYSTEM
# AI MARKETING AUTOMATION WORKFLOW ENGINE
# Code No: 127
# Version: 1.0
# ==================================================


class AI_Marketing_Automation_Workflow_Engine:

    def __init__(self):

        self.campaigns = []

        print("=" * 70)
        print("📢 AI MARKETING AUTOMATION WORKFLOW ENGINE")
        print("=" * 70)



    # ------------------------------------------------

    def add_campaign(
        self,
        product,
        platform,
        budget,
        clicks,
        sales
    ):

        self.campaigns.append({

            "Product": product,
            "Platform": platform,
            "Budget": budget,
            "Clicks": clicks,
            "Sales": sales

        })


        print(
            "✅ Campaign Added:",
            product,
            "-",
            platform
        )



    # ------------------------------------------------

    def analyze_campaigns(self):

        print("\n📊 MARKETING AUTOMATION REPORT")
        print("-" * 50)


        best_campaign = ""
        best_score = 0


        for campaign in self.campaigns:


            conversion = (
                campaign["Sales"]
                /
                campaign["Clicks"]
                *
                100
            )


            score = (
                conversion
                *
                10
            )


            print("\n📢 Product:",
                  campaign["Product"])

            print("📱 Platform:",
                  campaign["Platform"])

            print("💰 Budget: $",
                  campaign["Budget"])

            print("👆 Clicks:",
                  campaign["Clicks"])

            print("🛒 Sales:",
                  campaign["Sales"])

            print("📈 Conversion Rate:",
                  round(conversion,2),
                  "%")

            print("🧠 AI Campaign Score:",
                  round(score,2))



            if score > best_score:

                best_score = score

                best_campaign = (
                    campaign["Platform"]
                    +
                    " - "
                    +
                    campaign["Product"]
                )



            print("-" * 50)



        print("\n🏆 BEST CAMPAIGN:",
              best_campaign)


        print("\n🤖 AI MARKETING DECISION")
        print("-" * 50)

        print("🚀 Action: Increase Budget On Best Campaign")
        print("📈 Strategy: Optimize Advertising Performance")


        print("\n📢 Marketing Automation Status: ACTIVE")

        print("\n✅ Marketing Workflow Completed")



# ===============================
# SYSTEM TEST
# ===============================


MARKETING_AI = AI_Marketing_Automation_Workflow_Engine()


MARKETING_AI.add_campaign(
    "Car Phone Holder",
    "TikTok Ads",
    500,
    1000,
    80
)


MARKETING_AI.add_campaign(
    "LED Cabinet Light",
    "Facebook Ads",
    400,
    800,
    50
)


MARKETING_AI.add_campaign(
    "Mini Vacuum Cleaner",
    "Google Ads",
    450,
    600,
    70
)


MARKETING_AI.analyze_campaigns()