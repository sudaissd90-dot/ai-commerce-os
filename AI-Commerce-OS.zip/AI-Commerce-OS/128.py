# ==================================================
# AI E-COMMERCE AUTOPILOT SYSTEM
# AI BUSINESS ANALYTICS DASHBOARD ENGINE
# Code No: 128
# Version: 1.0
# ==================================================


class AI_Business_Analytics_Dashboard_Engine:

    def __init__(self):

        self.business_data = []

        print("=" * 70)
        print("📊 AI BUSINESS ANALYTICS DASHBOARD ENGINE")
        print("=" * 70)



    # ------------------------------------------------

    def add_data(
        self,
        department,
        revenue,
        orders,
        customers,
        performance
    ):

        self.business_data.append({

            "Department": department,
            "Revenue": revenue,
            "Orders": orders,
            "Customers": customers,
            "Performance": performance

        })


        print(
            "✅ Data Added:",
            department
        )



    # ------------------------------------------------

    def generate_dashboard(self):

        print("\n📊 BUSINESS ANALYTICS REPORT")
        print("-" * 50)


        total_revenue = 0
        total_orders = 0
        total_customers = 0
        total_score = 0


        for data in self.business_data:


            print("\n🏢 Department:",
                  data["Department"])

            print("💰 Revenue: $",
                  data["Revenue"])

            print("📦 Orders:",
                  data["Orders"])

            print("👥 Customers:",
                  data["Customers"])

            print("⭐ Performance:",
                  data["Performance"])



            total_revenue += data["Revenue"]
            total_orders += data["Orders"]
            total_customers += data["Customers"]
            total_score += data["Performance"]



        average_score = (
            total_score /
            len(self.business_data)
        )


        print("\n📈 COMPANY SUMMARY")
        print("-" * 50)

        print("💰 Total Revenue: $",
              total_revenue)

        print("📦 Total Orders:",
              total_orders)

        print("👥 Total Customers:",
              total_customers)

        print("🧠 Business Health Score:",
              round(average_score,2))



        print("\n👑 AI CEO ANALYSIS")
        print("-" * 50)


        if average_score >= 85:

            print("🚀 Status: HIGH PERFORMANCE BUSINESS")
            print("🌍 Action: Expand Operations")


        else:

            print("⚠️ Status: Improvement Required")
            print("🔧 Action: Optimize Departments")



        print("\n📊 Dashboard Status: ACTIVE")

        print("\n✅ Business Analytics Completed")



# ===============================
# SYSTEM TEST
# ===============================


DASHBOARD_AI = AI_Business_Analytics_Dashboard_Engine()


DASHBOARD_AI.add_data(
    "Sales",
    25000,
    500,
    800,
    90
)


DASHBOARD_AI.add_data(
    "Marketing",
    15000,
    300,
    500,
    85
)


DASHBOARD_AI.add_data(
    "Operations",
    12000,
    200,
    300,
    88
)


DASHBOARD_AI.generate_dashboard()