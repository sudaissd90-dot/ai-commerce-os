# ==================================================
# AI E-COMMERCE AUTOPILOT SYSTEM
# AI CEO STRATEGIC DECISION ENGINE
# Code No: 129
# Version: 1.0
# ==================================================


class AI_CEO_Strategic_Decision_Engine:

    def __init__(self):

        self.departments = []

        print("=" * 70)
        print("👑 AI CEO STRATEGIC DECISION ENGINE")
        print("=" * 70)



    # ------------------------------------------------

    def add_department(
        self,
        name,
        performance,
        growth,
        risk
    ):

        self.departments.append({

            "Name": name,
            "Performance": performance,
            "Growth": growth,
            "Risk": risk

        })


        print(
            "✅ Department Added:",
            name
        )



    # ------------------------------------------------

    def make_decision(self):

        print("\n📊 CEO STRATEGIC REPORT")
        print("-" * 50)


        total_score = 0


        for dept in self.departments:

            score = (
                dept["Performance"]
                +
                dept["Growth"]
                -
                dept["Risk"]
            )


            total_score += score


            print("\n🏢 Department:",
                  dept["Name"])

            print("⭐ Performance:",
                  dept["Performance"])

            print("📈 Growth:",
                  dept["Growth"])

            print("⚠️ Risk:",
                  dept["Risk"])

            print("🧠 Department Score:",
                  score)


            print("-" * 50)



        company_score = (
            total_score /
            len(self.departments)
        )


        print("\n👑 COMPANY STRATEGIC SCORE:",
              round(company_score,2))


        print("\n🤖 AI CEO FINAL DECISION")
        print("-" * 50)



        if company_score >= 120:

            print("🚀 Decision: AGGRESSIVE EXPANSION")
            print("🌍 Action: Enter New Markets")


        elif company_score >= 80:

            print("📈 Decision: CONTROLLED GROWTH")
            print("🚀 Action: Increase Investment")


        else:

            print("⚠️ Decision: OPTIMIZATION REQUIRED")
            print("🔧 Action: Improve Weak Areas")



        print("\n👑 CEO Decision System: ACTIVE")

        print("\n✅ Strategic Decision Completed")



# ===============================
# SYSTEM TEST
# ===============================


CEO_AI = AI_CEO_Strategic_Decision_Engine()


CEO_AI.add_department(
    "Product",
    95,
    90,
    10
)


CEO_AI.add_department(
    "Marketing",
    88,
    85,
    15
)


CEO_AI.add_department(
    "Sales",
    90,
    92,
    8
)


CEO_AI.add_department(
    "Finance",
    86,
    80,
    12
)


CEO_AI.make_decision()