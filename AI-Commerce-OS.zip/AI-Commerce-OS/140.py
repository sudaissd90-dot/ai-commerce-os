# ==================================================
# AI ENTERPRISE DATABASE ENGINE
# Code No: 140
# ==================================================

import sqlite3

print("=" * 70)
print("🗄️ AI ENTERPRISE DATABASE ENGINE")
print("=" * 70)

# Connect Database
conn = sqlite3.connect("ai_enterprise.db")
cursor = conn.cursor()

# Create Products Table
cursor.execute(
    "CREATE TABLE IF NOT EXISTS products ("
    "id INTEGER PRIMARY KEY AUTOINCREMENT, "
    "name TEXT, "
    "category TEXT, "
    "price REAL, "
    "stock INTEGER)"
)

conn.commit()

print("✅ Products Table Ready")

# Add Products
products = [
    ("Car Phone Holder", "Car Accessories", 18, 120),
    ("LED Cabinet Light", "Home Gadgets", 15, 80),
]

for product in products:
    cursor.execute(
        "INSERT INTO products (name, category, price, stock) "
        "VALUES (?, ?, ?, ?)",
        product
    )
    print("✅ Product Saved:", product[0])

conn.commit()

# Show Products
print("\n📦 PRODUCT DATABASE")
print("-" * 50)

cursor.execute("SELECT * FROM products")

rows = cursor.fetchall()

for row in rows:
    print(row)

conn.close()

print("\n✅ Database Closed")
print("\n[Program Finished]")