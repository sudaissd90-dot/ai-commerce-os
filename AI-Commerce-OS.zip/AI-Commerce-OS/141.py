# ==================================================
# AI ORDER DATABASE ENGINE
# Code No: 141
# ==================================================

import sqlite3
from datetime import datetime

print("=" * 70)
print("📦 AI ORDER DATABASE ENGINE")
print("=" * 70)

# Connect Database
conn = sqlite3.connect("ai_enterprise.db")
cursor = conn.cursor()

# Create Orders Table
cursor.execute(
    "CREATE TABLE IF NOT EXISTS orders ("
    "id INTEGER PRIMARY KEY AUTOINCREMENT, "
    "customer TEXT, "
    "product TEXT, "
    "quantity INTEGER, "
    "total REAL, "
    "order_date TEXT, "
    "status TEXT)"
)

conn.commit()

print("✅ Orders Table Ready")

# Sample Orders
orders = [
    ("Ali", "Car Phone Holder", 2, 36.0,
     datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
     "Completed"),

    ("Ahmed", "LED Cabinet Light", 1, 15.0,
     datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
     "Processing")
]

# Save Orders
for order in orders:

    cursor.execute(
        "INSERT INTO orders "
        "(customer, product, quantity, total, order_date, status) "
        "VALUES (?, ?, ?, ?, ?, ?)",
        order
    )

    print("✅ Order Saved:", order[0])

conn.commit()

# Show Orders
print("\n📊 ORDER DATABASE")
print("-" * 50)

cursor.execute("SELECT * FROM orders")

rows = cursor.fetchall()

for row in rows:
    print(row)

conn.close()

print("\n✅ Orders Database Closed")
print("\n[Program Finished]")