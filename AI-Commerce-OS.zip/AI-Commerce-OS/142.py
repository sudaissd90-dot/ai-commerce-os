# ==================================================
# AI CUSTOMER DATABASE ENGINE
# Code No: 142
# ==================================================

import sqlite3

print("=" * 70)
print("👤 AI CUSTOMER DATABASE ENGINE")
print("=" * 70)

# Connect Database
conn = sqlite3.connect("ai_enterprise.db")
cursor = conn.cursor()

# Create Customers Table
cursor.execute(
    "CREATE TABLE IF NOT EXISTS customers ("
    "id INTEGER PRIMARY KEY AUTOINCREMENT, "
    "name TEXT, "
    "email TEXT, "
    "phone TEXT, "
    "country TEXT, "
    "spending REAL, "
    "loyalty TEXT)"
)

conn.commit()

print("✅ Customers Table Ready")

# Sample Customers
customers = [

    (
        "Ali",
        "ali@gmail.com",
        "+923001111111",
        "Pakistan",
        700.0,
        "Gold"
    ),

    (
        "Ahmed",
        "ahmed@gmail.com",
        "+923002222222",
        "Pakistan",
        120.0,
        "Silver"
    ),

    (
        "Usman",
        "usman@gmail.com",
        "+923003333333",
        "Pakistan",
        1000.0,
        "VIP"
    )

]

# Save Customers
for customer in customers:

    cursor.execute(

        "INSERT INTO customers "
        "(name, email, phone, country, spending, loyalty) "
        "VALUES (?, ?, ?, ?, ?, ?)",

        customer

    )

    print("✅ Customer Saved:", customer[0])

conn.commit()

# Show Customers
print("\n👥 CUSTOMER DATABASE")
print("-" * 50)

cursor.execute("SELECT * FROM customers")

rows = cursor.fetchall()

for row in rows:

    print(row)

conn.close()

print("\n✅ Customer Database Closed")
print("\n[Program Finished]")