# ==================================================
# AI SUPPLIER DATABASE ENGINE
# Code No: 143
# ==================================================

import sqlite3

print("=" * 70)
print("🏢 AI SUPPLIER DATABASE ENGINE")
print("=" * 70)

# Connect Database
conn = sqlite3.connect("ai_enterprise.db")
cursor = conn.cursor()

# Create Suppliers Table
cursor.execute(
    "CREATE TABLE IF NOT EXISTS suppliers ("
    "id INTEGER PRIMARY KEY AUTOINCREMENT, "
    "name TEXT, "
    "email TEXT, "
    "phone TEXT, "
    "country TEXT, "
    "product_cost REAL, "
    "quality_score INTEGER, "
    "delivery_score INTEGER)"
)

conn.commit()

print("✅ Suppliers Table Ready")

# Sample Suppliers
suppliers = [

    (
        "Supplier A",
        "suppliera@gmail.com",
        "+111111111",
        "China",
        8.0,
        95,
        90
    ),

    (
        "Supplier B",
        "supplierb@gmail.com",
        "+222222222",
        "Pakistan",
        6.0,
        80,
        85
    ),

    (
        "Supplier C",
        "supplierc@gmail.com",
        "+333333333",
        "Turkey",
        10.0,
        98,
        95
    )

]

# Save Suppliers
for supplier in suppliers:

    cursor.execute(

        "INSERT INTO suppliers "
        "(name, email, phone, country, product_cost, quality_score, delivery_score) "
        "VALUES (?, ?, ?, ?, ?, ?, ?)",

        supplier

    )

    print("✅ Supplier Saved:", supplier[0])

conn.commit()

# Show Suppliers
print("\n🏢 SUPPLIER DATABASE")
print("-" * 50)

cursor.execute("SELECT * FROM suppliers")

rows = cursor.fetchall()

for row in rows:
    print(row)

conn.close()

print("\n✅ Supplier Database Closed")
print("\n[Program Finished]")