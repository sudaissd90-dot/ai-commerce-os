# ==================================================
# AI E-COMMERCE AUTOPILOT SYSTEM
# AI CUSTOMER SUPPORT AGENT
# Code No: 11
# Version: 2.0
# ==================================================


class AI_Customer_Support:


    def __init__(self):
        self.status = "ONLINE"



    def reply(self, question):

        print("=" * 55)
        print("🤖 AI CUSTOMER SUPPORT AGENT")
        print("=" * 55)


        print("\nCustomer Question:")
        print(question)


        question = question.lower()



        if "delivery" in question:

            answer = (
                "Your order is being processed. "
                "Delivery updates will be provided soon."
            )


        elif "price" in question:

            answer = (
                "Our product price is competitive "
                "with high quality standards."
            )


        elif "return" in question:

            answer = (
                "You can request a return according "
                "to our return policy."
            )


        elif "product" in question:

            answer = (
                "This product is designed for "
                "daily convenience and easy use."
            )


        else:

            answer = (
                "Thank you for contacting us. "
                "Our support team will assist you."
            )



        print("\n🤖 AI Response:")
        print(answer)


        print("\n✅ Support Completed")



# ===============================
# SYSTEM TEST
# ===============================


SUPPORT_AI = AI_Customer_Support()


SUPPORT_AI.reply(
    "Where is my delivery?"
)