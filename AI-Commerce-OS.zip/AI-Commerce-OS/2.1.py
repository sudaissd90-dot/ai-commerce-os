# ==================================================
# AI E-COMMERCE AUTOPILOT SYSTEM
# AI SALES FORECAST ENGINE
# Code No: 12
# Version: 2.1
# ==================================================


class AI_Sales_Forecast:


    def __init__(self):
        self.status = "ONLINE"



    def forecast(self, product_name):

        print("=" * 55)
        print("📈 AI SALES FORECAST ENGINE")
        print("=" * 55)


        print("\n📦 Product:")
        print(product_name)



        sales_history = [

            20,
            35,
            45,
            60,
            75

        ]


        total_sales = sum(sales_history)

        average_sales = (
            total_sales /
            len(sales_history)
        )


        predicted_sales = (
            average_sales * 1.25
        )



        print("\n📊 SALES HISTORY")
        print("-" * 40)


        for month, sales in enumerate(sales_history, 1):

            print(
                "Month",
                month,
                ":",
                sales,
                "Orders"
            )


        print("\n📌 Average Monthly Sales:")
        print(round(average_sales, 2),
              "Orders")


        print("\n🚀 AI Forecast Next Month:")
        print(round(predicted_sales, 2),
              "Orders")


        print("\n✅ Sales Forecast Completed")



# ===============================
# SYSTEM TEST
# ===============================


FORECAST_AI = AI_Sales_Forecast()


FORECAST_AI.forecast(
    "Car Phone Holder"
)