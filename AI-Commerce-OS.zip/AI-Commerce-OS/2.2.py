# ==================================================
# AI E-COMMERCE AUTOPILOT SYSTEM
# AI COMPETITOR ANALYSIS ENGINE
# Code No: 13
# Version: 2.2
# ==================================================


class AI_Competitor_Analysis:


    def __init__(self):
        self.status = "ONLINE"



    def analyze_competitors(self, product_name):

        print("=" * 55)
        print("⚔️ AI COMPETITOR ANALYSIS ENGINE")
        print("=" * 55)


        print("\n📦 Product:")
        print(product_name)


        competitors = [

            {
                "name": "Competitor Store A",
                "price": 18,
                "rating": 4.5
            },

            {
                "name": "Competitor Store B",
                "price": 22,
                "rating": 4.2
            },

            {
                "name": "Competitor Store C",
                "price": 16,
                "rating": 4.7
            }

        ]


        print("\n🏪 MARKET COMPETITORS")
        print("-" * 40)


        average_price = 0


        for competitor in competitors:

            print(
                competitor["name"]
            )

            print(
                "Price: $",
                competitor["price"]
            )

            print(
                "Rating:",
                competitor["rating"]
            )

            print("-" * 20)


            average_price += competitor["price"]



        average_price = (
            average_price /
            len(competitors)
        )


        print("\n📊 AI MARKET REPORT")
        print("-" * 40)


        print(
            "Average Competitor Price: $",
            round(average_price, 2)
        )


        print(
            "Competition Level: MEDIUM"
        )


        print(
            "Strategy: Offer Better Value"
        )


        print("\n✅ Competitor Analysis Completed")



# ===============================
# SYSTEM TEST
# ===============================


COMPETITOR_AI = AI_Competitor_Analysis()


COMPETITOR_AI.analyze_competitors(
    "Car Phone Holder"
)