# ==================================================
# AI E-COMMERCE AUTOPILOT SYSTEM
# AI SUPPLIER FINDER ENGINE
# Code No: 14
# Version: 2.3
# ==================================================


class AI_Supplier_Finder:


    def __init__(self):
        self.status = "ONLINE"



    def find_supplier(self, product_name):

        print("=" * 55)
        print("🌍 AI SUPPLIER FINDER ENGINE")
        print("=" * 55)


        print("\n📦 Product:")
        print(product_name)



        suppliers = [

            {
                "name": "Supplier A",
                "cost": 6,
                "delivery": "Fast",
                "rating": 4.6
            },

            {
                "name": "Supplier B",
                "cost": 5,
                "delivery": "Medium",
                "rating": 4.3
            },

            {
                "name": "Supplier C",
                "cost": 8,
                "delivery": "Very Fast",
                "rating": 4.8
            }

        ]



        print("\n🏭 SUPPLIER OPTIONS")
        print("-" * 40)



        best_supplier = None
        lowest_cost = 999



        for supplier in suppliers:


            print(
                supplier["name"]
            )

            print(
                "Cost: $",
                supplier["cost"]
            )

            print(
                "Delivery:",
                supplier["delivery"]
            )

            print(
                "Rating:",
                supplier["rating"]
            )

            print("-" * 20)



            if supplier["cost"] < lowest_cost:

                lowest_cost = supplier["cost"]
                best_supplier = supplier["name"]



        print("\n🤖 AI SUPPLIER RECOMMENDATION")
        print("-" * 40)

        print(
            "Best Supplier:",
            best_supplier
        )

        print(
            "Reason: Lowest Product Cost"
        )


        print("\n✅ Supplier Search Completed")



# ===============================
# SYSTEM TEST
# ===============================


SUPPLIER_AI = AI_Supplier_Finder()


SUPPLIER_AI.find_supplier(
    "Car Phone Holder"
)