# ==================================================
# AI E-COMMERCE AUTOPILOT SYSTEM
# AI PROFIT CALCULATOR ENGINE
# Code No: 15
# Version: 2.4
# ==================================================


class AI_Profit_Calculator:


    def __init__(self):
        self.status = "ONLINE"



    def calculate_profit(self, product_name,
                         supplier_cost,
                         selling_price):

        print("=" * 55)
        print("💰 AI PROFIT CALCULATOR ENGINE")
        print("=" * 55)


        print("\n📦 Product:")
        print(product_name)



        platform_fee = 2
        marketing_cost = 1



        total_cost = (
            supplier_cost +
            platform_fee +
            marketing_cost
        )


        profit = (
            selling_price -
            total_cost
        )


        profit_margin = (
            profit /
            selling_price
        ) * 100



        print("\n📊 PROFIT ANALYSIS")
        print("-" * 40)


        print("Supplier Cost: $", supplier_cost)

        print("Platform Fee: $", platform_fee)

        print("Marketing Cost: $", marketing_cost)


        print("\nTotal Cost: $",
              round(total_cost, 2))


        print("Selling Price: $",
              selling_price)


        print("\n💵 Net Profit: $",
              round(profit, 2))


        print("📈 Profit Margin:",
              round(profit_margin, 2),
              "%")



        if profit_margin >= 30:

            print("\n🚀 AI Decision: HIGH PROFIT PRODUCT")

        elif profit_margin >= 15:

            print("\n⚠️ AI Decision: ACCEPTABLE PROFIT")

        else:

            print("\n❌ AI Decision: LOW PROFIT")



        print("\n✅ Profit Calculation Completed")



# ===============================
# SYSTEM TEST
# ===============================


PROFIT_AI = AI_Profit_Calculator()


PROFIT_AI.calculate_profit(
    "Car Phone Holder",
    5,
    18
)