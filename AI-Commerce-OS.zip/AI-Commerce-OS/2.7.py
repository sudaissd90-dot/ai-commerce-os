# ==================================================
# AI E-COMMERCE AUTOPILOT SYSTEM
# AI CEO DECISION MAKING ENGINE
# Code No: 18
# Version: 2.7
# ==================================================


class AI_CEO_Decision_Engine:


    def __init__(self):
        self.status = "ONLINE"



    def make_decision(self,
                      product,
                      profit_margin,
                      demand_score,
                      competition):


        print("=" * 60)
        print("👔 AI CEO DECISION MAKING ENGINE")
        print("=" * 60)


        print("\n📦 Product:")
        print(product)


        print("\n📊 Business Analysis")
        print("-" * 40)

        print(
            "Profit Margin:",
            profit_margin,
            "%"
        )

        print(
            "Demand Score:",
            demand_score,
            "/10"
        )

        print(
            "Competition:",
            competition,
            "/10"
        )



        if profit_margin >= 40 and demand_score >= 7:

            decision = "🚀 LAUNCH PRODUCT"

            reason = (
                "High profit and strong market demand"
            )


        elif profit_margin >= 20:

            decision = "⚠️ REVIEW PRODUCT"

            reason = (
                "Product has potential but needs improvement"
            )


        else:

            decision = "❌ REJECT PRODUCT"

            reason = (
                "Low business opportunity"
            )



        print("\n🤖 AI CEO FINAL DECISION")
        print("-" * 40)

        print(
            "Decision:",
            decision
        )

        print(
            "Reason:",
            reason
        )


        print("\n✅ CEO Analysis Completed")



# ===============================
# SYSTEM TEST
# ===============================


CEO_AI = AI_CEO_Decision_Engine()


CEO_AI.make_decision(
    "Car Phone Holder",
    55,
    9,
    7
)