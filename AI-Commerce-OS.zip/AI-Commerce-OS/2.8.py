# ==================================================
# AI E-COMMERCE AUTOPILOT SYSTEM
# AI MEMORY SYSTEM
# Code No: 19
# Version: 2.8
# ==================================================


class AI_Memory_System:


    def __init__(self):

        self.status = "ONLINE"
        self.memory = []



    def save_memory(self, product, decision):

        record = {

            "product": product,
            "decision": decision

        }


        self.memory.append(record)



        print("\n💾 Memory Saved")

        print(
            "Product:",
            product
        )

        print(
            "Decision:",
            decision
        )



    def show_memory(self):

        print("=" * 55)
        print("🧠 AI MEMORY DATABASE")
        print("=" * 55)


        if not self.memory:

            print("Memory Empty")


        else:

            for number, item in enumerate(self.memory, 1):

                print(
                    number,
                    item
                )



        print("\n✅ Memory Check Completed")



# ===============================
# SYSTEM TEST
# ===============================


MEMORY_AI = AI_Memory_System()


MEMORY_AI.save_memory(
    "Car Phone Holder",
    "LAUNCH PRODUCT"
)


MEMORY_AI.save_memory(
    "Smart LED Cabinet Light",
    "NEEDS REVIEW"
)


MEMORY_AI.show_memory()