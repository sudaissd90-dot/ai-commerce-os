# ==================================================
# AI E-COMMERCE AUTOPILOT SYSTEM
# AI LEARNING & IMPROVEMENT ENGINE
# Code No: 22
# Version: 3.2
# ==================================================


class AI_Learning_Engine:


    def __init__(self):

        self.status = "ONLINE"
        self.history = []



    def record_result(self, product, result):

        data = {

            "product": product,
            "result": result

        }


        self.history.append(data)


        print("\n🧠 Learning Data Saved")

        print(
            "Product:",
            product
        )

        print(
            "Result:",
            result
        )



    def analyze_learning(self):

        print("=" * 60)
        print("🧠 AI LEARNING & IMPROVEMENT ENGINE")
        print("=" * 60)


        print("\n📊 Previous Results")
        print("-" * 40)


        success = 0
        failed = 0


        for item in self.history:


            print(item)


            if item["result"] == "SUCCESS":

                success += 1

            else:

                failed += 1



        print("\n📈 AI PERFORMANCE")

        print(
            "Successful Products:",
            success
        )

        print(
            "Failed Products:",
            failed
        )



        if success > failed:

            print(
                "\n🚀 AI Learning Status: IMPROVING"
            )

        else:

            print(
                "\n⚠️ AI Needs More Data"
            )



        print("\n✅ Learning Analysis Completed")



# ===============================
# SYSTEM TEST
# ===============================


LEARNING_AI = AI_Learning_Engine()


LEARNING_AI.record_result(
    "Car Phone Holder",
    "SUCCESS"
)


LEARNING_AI.record_result(
    "Smart LED Cabinet Light",
    "FAILED"
)


LEARNING_AI.analyze_learning()