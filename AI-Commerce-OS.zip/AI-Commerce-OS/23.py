# ==================================================
# AI E-COMMERCE AUTOPILOT SYSTEM
# AI RISK MANAGEMENT ENGINE
# Code No: 23
# Version: 3.3
# ==================================================


class AI_Risk_Management:


    def __init__(self):

        self.status = "ONLINE"



    def analyze_risk(self,
                     product,
                     competition,
                     profit_margin,
                     demand):


        print("=" * 60)
        print("⚠️ AI RISK MANAGEMENT ENGINE")
        print("=" * 60)



        print("\n📦 Product:")
        print(product)



        print("\n📊 RISK ANALYSIS")
        print("-" * 40)


        print(
            "Competition:",
            competition,
            "/10"
        )


        print(
            "Profit Margin:",
            profit_margin,
            "%"
        )


        print(
            "Demand Score:",
            demand,
            "/10"
        )



        risk_score = 0



        if competition >= 8:

            risk_score += 2


        if profit_margin < 20:

            risk_score += 2


        if demand < 5:

            risk_score += 2



        print(
            "\nRisk Score:",
            risk_score,
            "/6"
        )



        if risk_score <= 1:

            decision = "🟢 LOW RISK"


        elif risk_score <= 3:

            decision = "🟡 MEDIUM RISK"


        else:

            decision = "🔴 HIGH RISK"



        print(
            "\n🤖 AI Risk Decision:"
        )

        print(decision)



        print("\n✅ Risk Analysis Completed")



# ===============================
# SYSTEM TEST
# ===============================


RISK_AI = AI_Risk_Management()


RISK_AI.analyze_risk(
    "Car Phone Holder",
    7,
    55,
    9
)