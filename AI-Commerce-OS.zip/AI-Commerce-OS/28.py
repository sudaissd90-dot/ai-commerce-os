# ==================================================
# AI E-COMMERCE AUTOPILOT SYSTEM
# AI PRODUCT RANKING ENGINE
# Code No: 28
# Version: 3.8
# ==================================================


class AI_Product_Ranking_Engine:


    def __init__(self):

        self.status = "ONLINE"



    def rank_products(self):


        print("=" * 65)
        print("🏆 AI PRODUCT RANKING ENGINE")
        print("=" * 65)



        products = [

            {
                "name": "Smart Watch",
                "demand": 8,
                "profit": 7,
                "competition": 7
            },

            {
                "name": "Car Phone Holder",
                "demand": 9,
                "profit": 9,
                "competition": 6
            },

            {
                "name": "Pet Hair Remover",
                "demand": 7,
                "profit": 8,
                "competition": 5
            },

            {
                "name": "Portable Blender",
                "demand": 8,
                "profit": 8,
                "competition": 7
            }

        ]



        print("\n📊 PRODUCT SCORES")
        print("-" * 45)



        winner = None
        highest_score = 0



        for product in products:


            score = (

                product["demand"] +
                product["profit"] +
                (10 - product["competition"])

            )


            print(
                product["name"],
                "Score:",
                score,
                "/30"
            )



            if score > highest_score:

                highest_score = score
                winner = product["name"]



        print("\n🥇 AI WINNER PRODUCT")

        print("-" * 45)


        print(
            "Product:",
            winner
        )


        print(
            "Score:",
            highest_score,
            "/30"
        )


        print(
            "Recommendation: TEST THIS PRODUCT FIRST 🚀"
        )



        print("\n✅ Product Ranking Completed")



# ===============================
# SYSTEM TEST
# ===============================


RANKING_AI = AI_Product_Ranking_Engine()


RANKING_AI.rank_products()