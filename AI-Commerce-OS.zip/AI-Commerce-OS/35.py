# ==================================================
# AI E-COMMERCE AUTOPILOT SYSTEM
# AI FINANCE MANAGER AGENT
# Code No: 35
# Version: 4.5
# ==================================================


class AI_Finance_Manager_Agent:


    def __init__(self):

        self.status = "ONLINE"



    def analyze_finance(self, product):


        print("=" * 70)
        print("💰 AI FINANCE MANAGER AGENT")
        print("=" * 70)



        print("\n📦 Product:")
        print(product)



        revenue = 1800

        product_cost = 500

        marketing_cost = 200

        platform_fee = 100



        total_expense = (
            product_cost +
            marketing_cost +
            platform_fee
        )


        profit = revenue - total_expense



        print("\n📊 FINANCIAL REPORT")

        print("-" * 50)



        print(
            "Total Revenue: $",
            revenue
        )


        print(
            "Product Cost: $",
            product_cost
        )


        print(
            "Marketing Cost: $",
            marketing_cost
        )


        print(
            "Platform Fee: $",
            platform_fee
        )


        print(
            "Total Expense: $",
            total_expense
        )


        print(
            "Net Profit: $",
            profit
        )



        print("\n🤖 AI FINANCE DECISION")

        print("-" * 50)



        if profit > 500:

            print(
                "Financial Status: STRONG 🚀"
            )

            print(
                "Recommendation: Increase Investment"
            )

        else:

            print(
                "Financial Status: NEEDS IMPROVEMENT"
            )



        print("\n✅ Finance Analysis Completed")



# ===============================
# SYSTEM TEST
# ===============================


FINANCE_AI = AI_Finance_Manager_Agent()


FINANCE_AI.analyze_finance(
    "Car Phone Holder"
)