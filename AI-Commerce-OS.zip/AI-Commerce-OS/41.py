# ==================================================
# AI E-COMMERCE AUTOPILOT SYSTEM
# AI SHARED MEMORY SYSTEM
# Code No: 41
# Version: 1.0
# ==================================================


class AI_Shared_Memory:

    def __init__(self):

        self.memory = {}

        print("=" * 70)
        print("🧠 AI SHARED MEMORY SYSTEM")
        print("=" * 70)

        print("Status : ONLINE")

    # ----------------------------------------------

    def save(self, key, value):

        self.memory[key] = value

        print("✅ Saved:", key)

    # ----------------------------------------------

    def load(self, key):

        if key in self.memory:

            print("📂 Loaded:", key)

            return self.memory[key]

        else:

            print("❌ Data Not Found")

            return None

    # ----------------------------------------------

    def show_memory(self):

        print("\n📦 SHARED MEMORY DATA")
        print("-" * 50)

        if len(self.memory) == 0:

            print("Memory Empty")

        else:

            for key, value in self.memory.items():

                print(key, ":", value)


# ===============================
# SYSTEM TEST
# ===============================

MEMORY = AI_Shared_Memory()

MEMORY.save("Product", "Car Phone Holder")
MEMORY.save("Cost", "$5")
MEMORY.save("Selling Price", "$18")
MEMORY.save("Stock", 100)

print()

MEMORY.load("Product")

MEMORY.show_memory()