# ==================================================
# AI E-COMMERCE AUTOPILOT SYSTEM
# AI MULTI-AGENT COMMUNICATION SYSTEM
# Code No: 42
# Version: 1.0
# ==================================================


class AI_Multi_Agent_Communication:

    def __init__(self):

        print("=" * 70)
        print("🤖 AI MULTI-AGENT COMMUNICATION SYSTEM")
        print("=" * 70)

        self.messages = []

    # ----------------------------------------------

    def send_message(self, sender, receiver, message):

        data = {
            "Sender": sender,
            "Receiver": receiver,
            "Message": message
        }

        self.messages.append(data)

        print("✅ Message Sent")

    # ----------------------------------------------

    def show_messages(self):

        print("\n📨 AI COMMUNICATION LOG")
        print("-" * 50)

        if len(self.messages) == 0:

            print("No Messages")

        else:

            for msg in self.messages:

                print(
                    msg["Sender"],
                    "➡",
                    msg["Receiver"]
                )

                print(
                    "Message:",
                    msg["Message"]
                )

                print("-" * 50)


# ===============================
# SYSTEM TEST
# ===============================

COMM = AI_Multi_Agent_Communication()

COMM.send_message(
    "Product Hunter",
    "Product Analyzer",
    "New Product Found"
)

COMM.send_message(
    "Product Analyzer",
    "Pricing AI",
    "Price Analysis Completed"
)

COMM.send_message(
    "Pricing AI",
    "Advertising AI",
    "Launch Campaign"
)

COMM.show_messages()