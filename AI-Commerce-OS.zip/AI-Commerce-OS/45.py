# ==================================================
# AI E-COMMERCE AUTOPILOT SYSTEM
# AI PRODUCT DATABASE MANAGER
# Code No: 45
# Version: 1.0
# ==================================================


class AI_Product_Database_Manager:

    def __init__(self):

        self.products = []

        print("=" * 70)
        print("🗄️ AI PRODUCT DATABASE MANAGER")
        print("=" * 70)

    # ------------------------------------------------

    def add_product(self, name, cost, price, stock):

        product = {
            "Name": name,
            "Cost": cost,
            "Price": price,
            "Stock": stock
        }

        self.products.append(product)

        print("✅ Product Added:", name)

    # ------------------------------------------------

    def show_products(self):

        print("\n📦 PRODUCT DATABASE")
        print("-" * 50)

        if len(self.products) == 0:

            print("No Products Available")

        else:

            number = 1

            for product in self.products:

                print("\nProduct", number)

                print("Name :", product["Name"])
                print("Cost :", product["Cost"])
                print("Price :", product["Price"])
                print("Stock :", product["Stock"])

                number += 1


# ===============================
# SYSTEM TEST
# ===============================

DB = AI_Product_Database_Manager()

DB.add_product(
    "Car Phone Holder",
    5,
    18,
    100
)

DB.add_product(
    "LED Cabinet Light",
    4,
    15,
    200
)

DB.add_product(
    "Mini Vacuum Cleaner",
    10,
    29,
    50
)

DB.show_products()