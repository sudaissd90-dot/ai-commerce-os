# ==================================================
# AI E-COMMERCE AUTOPILOT SYSTEM
# AI PRODUCT SEARCH ENGINE
# Code No: 46
# Version: 1.0
# ==================================================


class AI_Product_Search_Engine:

    def __init__(self):

        self.products = []

        print("=" * 70)
        print("🔍 AI PRODUCT SEARCH ENGINE")
        print("=" * 70)

    # ------------------------------------------------

    def add_product(self, name, cost, price, stock):

        product = {
            "Name": name,
            "Cost": cost,
            "Price": price,
            "Stock": stock
        }

        self.products.append(product)

    # ------------------------------------------------

    def search_product(self, product_name):

        print("\n🔎 SEARCH RESULT")
        print("-" * 50)

        found = False

        for product in self.products:

            if product["Name"].lower() == product_name.lower():

                print("✅ Product Found")
                print("Name :", product["Name"])
                print("Cost :", product["Cost"])
                print("Price :", product["Price"])
                print("Stock :", product["Stock"])

                found = True
                break

        if not found:
            print("❌ Product Not Found")


# ===============================
# SYSTEM TEST
# ===============================

SEARCH = AI_Product_Search_Engine()

SEARCH.add_product(
    "Car Phone Holder",
    5,
    18,
    100
)

SEARCH.add_product(
    "LED Cabinet Light",
    4,
    15,
    200
)

SEARCH.add_product(
    "Mini Vacuum Cleaner",
    10,
    29,
    50
)

SEARCH.search_product(
    "Car Phone Holder"
)