# ==================================================
# AI E-COMMERCE AUTOPILOT SYSTEM
# AI INVENTORY MONITORING SYSTEM
# Code No: 47
# Version: 1.0
# ==================================================


class AI_Inventory_Monitoring_System:

    def __init__(self):

        self.products = []

        print("=" * 70)
        print("📦 AI INVENTORY MONITORING SYSTEM")
        print("=" * 70)


    # ------------------------------------------------

    def add_product(self, name, stock):

        self.products.append({
            "Name": name,
            "Stock": stock
        })


    # ------------------------------------------------

    def check_inventory(self):

        print("\n📋 INVENTORY REPORT")
        print("-" * 50)


        for product in self.products:

            stock = product["Stock"]

            print("\nProduct :", product["Name"])
            print("Stock   :", stock)


            if stock == 0:

                print("❌ Status : OUT OF STOCK")
                print("🔄 Action : REORDER IMMEDIATELY")


            elif stock <= 20:

                print("⚠️ Status : LOW STOCK")
                print("📦 Action : REORDER SOON")


            else:

                print("✅ Status : STOCK AVAILABLE")



# ===============================
# SYSTEM TEST
# ===============================

INVENTORY = AI_Inventory_Monitoring_System()


INVENTORY.add_product(
    "Car Phone Holder",
    100
)


INVENTORY.add_product(
    "LED Cabinet Light",
    15
)


INVENTORY.add_product(
    "Mini Vacuum Cleaner",
    0
)


INVENTORY.check_inventory()