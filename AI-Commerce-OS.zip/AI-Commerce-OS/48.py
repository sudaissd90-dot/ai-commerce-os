# ==================================================
# AI E-COMMERCE AUTOPILOT SYSTEM
# AI AUTO RESTOCK MANAGER
# Code No: 48
# Version: 1.0
# ==================================================


class AI_Auto_Restock_Manager:

    def __init__(self):

        self.products = []

        print("=" * 70)
        print("🔄 AI AUTO RESTOCK MANAGER")
        print("=" * 70)

    # ------------------------------------------------

    def add_product(self, name, stock):

        self.products.append({
            "Name": name,
            "Stock": stock
        })

    # ------------------------------------------------

    def generate_restock_list(self):

        print("\n📦 RESTOCK REPORT")
        print("-" * 50)

        found = False

        for product in self.products:

            if product["Stock"] <= 20:

                found = True

                print("Product :", product["Name"])
                print("Current Stock :", product["Stock"])
                print("Recommended Restock : 100 Units")
                print("-" * 50)

        if not found:

            print("✅ All Products Have Sufficient Stock")


# ===============================
# SYSTEM TEST
# ===============================

RESTOCK = AI_Auto_Restock_Manager()

RESTOCK.add_product(
    "Car Phone Holder",
    100
)

RESTOCK.add_product(
    "LED Cabinet Light",
    15
)

RESTOCK.add_product(
    "Mini Vacuum Cleaner",
    0
)

RESTOCK.generate_restock_list()