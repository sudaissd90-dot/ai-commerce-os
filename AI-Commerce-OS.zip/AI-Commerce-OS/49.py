# ==================================================
# AI E-COMMERCE AUTOPILOT SYSTEM
# AI SUPPLIER MANAGER
# Code No: 49
# Version: 1.0
# ==================================================


class AI_Supplier_Manager:

    def __init__(self):

        self.suppliers = []

        print("=" * 70)
        print("🏭 AI SUPPLIER MANAGER")
        print("=" * 70)

    # ------------------------------------------------

    def add_supplier(self, supplier_name, product, cost):

        self.suppliers.append({
            "Supplier": supplier_name,
            "Product": product,
            "Cost": cost
        })

        print("✅ Supplier Added:", supplier_name)

    # ------------------------------------------------

    def show_suppliers(self):

        print("\n📋 SUPPLIER DATABASE")
        print("-" * 50)

        if len(self.suppliers) == 0:

            print("No Suppliers Available")

        else:

            number = 1

            for supplier in self.suppliers:

                print("\nSupplier", number)
                print("Name    :", supplier["Supplier"])
                print("Product :", supplier["Product"])
                print("Cost    : $", supplier["Cost"])

                number += 1


# ===============================
# SYSTEM TEST
# ===============================

SUPPLIER = AI_Supplier_Manager()

SUPPLIER.add_supplier(
    "Alibaba Supplier A",
    "Car Phone Holder",
    5
)

SUPPLIER.add_supplier(
    "Alibaba Supplier B",
    "LED Cabinet Light",
    4
)

SUPPLIER.add_supplier(
    "Alibaba Supplier C",
    "Mini Vacuum Cleaner",
    10
)

SUPPLIER.show_suppliers()