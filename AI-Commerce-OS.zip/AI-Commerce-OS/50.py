# ==================================================
# AI E-COMMERCE AUTOPILOT SYSTEM
# AI SMART PURCHASING MANAGER
# Code No: 50
# Version: 1.0
# ==================================================


class AI_Smart_Purchasing_Manager:

    def __init__(self):

        self.suppliers = []

        print("=" * 70)
        print("🛒 AI SMART PURCHASING MANAGER")
        print("=" * 70)

    # ------------------------------------------------

    def add_supplier(self, supplier, product, cost):

        self.suppliers.append({
            "Supplier": supplier,
            "Product": product,
            "Cost": cost
        })

    # ------------------------------------------------

    def find_best_supplier(self, product_name):

        print("\n🔍 SMART PURCHASING REPORT")
        print("-" * 50)

        best_supplier = None

        for supplier in self.suppliers:

            if supplier["Product"].lower() == product_name.lower():

                if best_supplier is None or supplier["Cost"] < best_supplier["Cost"]:
                    best_supplier = supplier

        if best_supplier:

            print("✅ Best Supplier Found")
            print("Supplier :", best_supplier["Supplier"])
            print("Product  :", best_supplier["Product"])
            print("Best Cost: $", best_supplier["Cost"])

        else:

            print("❌ No Supplier Found")


# ===============================
# SYSTEM TEST
# ===============================

PURCHASE = AI_Smart_Purchasing_Manager()

PURCHASE.add_supplier(
    "Alibaba Supplier A",
    "Car Phone Holder",
    5
)

PURCHASE.add_supplier(
    "Alibaba Supplier B",
    "Car Phone Holder",
    4
)

PURCHASE.add_supplier(
    "Alibaba Supplier C",
    "Car Phone Holder",
    6
)

PURCHASE.find_best_supplier(
    "Car Phone Holder"
)