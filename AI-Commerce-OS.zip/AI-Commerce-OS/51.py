# ==================================================
# AI E-COMMERCE AUTOPILOT SYSTEM
# AI CORE SYSTEM MANAGER
# Code No: 51
# Version: 2.0
# ==================================================


class AI_Core_System_Manager:

    def __init__(self):

        self.modules = []

        print("=" * 70)
        print("🧠 AI CORE SYSTEM MANAGER")
        print("=" * 70)

    # ------------------------------------------------

    def register_module(self, module_name):

        self.modules.append(module_name)

        print("✅ Module Registered :", module_name)

    # ------------------------------------------------

    def show_modules(self):

        print("\n📦 REGISTERED AI MODULES")
        print("-" * 50)

        if len(self.modules) == 0:

            print("No Modules Registered")

        else:

            number = 1

            for module in self.modules:

                print(str(number) + ".", module)

                number += 1

        print("\n🤖 Total Modules :", len(self.modules))
        print("System Status : ONLINE")


# ===============================
# SYSTEM TEST
# ===============================

CORE = AI_Core_System_Manager()

CORE.register_module("Product Analyzer")
CORE.register_module("Pricing Optimization")
CORE.register_module("Advertising Campaign)