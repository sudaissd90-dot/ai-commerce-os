# ==================================================
# AI E-COMMERCE AUTOPILOT SYSTEM
# AI MODULE LOADER
# Code No: 52
# Version: 2.0
# ==================================================


class AI_Module_Loader:

    def __init__(self):

        self.loaded_modules = []

        print("=" * 70)
        print("📂 AI MODULE LOADER")
        print("=" * 70)

    # ------------------------------------------------

    def load_module(self, module_name):

        self.loaded_modules.append(module_name)

        print("✅ Loaded:", module_name)

    # ------------------------------------------------

    def show_loaded_modules(self):

        print("\n📋 LOADED MODULES")
        print("-" * 50)

        if len(self.loaded_modules) == 0:

            print("No Modules Loaded")

        else:

            count = 1

            for module in self.loaded_modules:

                print(str(count) + ".", module)

                count += 1

        print("\n📦 Total Loaded Modules:", len(self.loaded_modules))


# ===============================
# SYSTEM TEST
# ===============================

LOADER = AI_Module_Loader()

LOADER.load_module("Product Analyzer")
LOADER.load_module("Pricing Optimization")
LOADER.load_module("Advertising Campaign Manager")
LOADER.load_module("Workflow Automation Engine")
LOADER.load_module("Decision Engine Pro")
LOADER.load_module("Inventory Monitoring System")
LOADER.load_module("Supplier Manager")
LOADER.load_module("Smart Purchasing Manager")

LOADER.show_loaded_modules()