# ==================================================
# AI E-COMMERCE AUTOPILOT SYSTEM
# AI SYSTEM HEALTH MONITOR
# Code No: 53
# Version: 2.0
# ==================================================


class AI_System_Health_Monitor:

    def __init__(self):

        self.modules = {}

        print("=" * 70)
        print("💚 AI SYSTEM HEALTH MONITOR")
        print("=" * 70)

    # ------------------------------------------------

    def add_module(self, module_name, status):

        self.modules[module_name] = status

    # ------------------------------------------------

    def check_health(self):

        print("\n📊 SYSTEM HEALTH REPORT")
        print("-" * 50)

        online = 0

        total = len(self.modules)

        for module, status in self.modules.items():

            print(module + " :", status)

            if status == "ONLINE":
                online += 1

        print("-" * 50)

        health = (online / total) * 100

        print("Online Modules :", online)
        print("Total Modules  :", total)
        print("System Health  :", str(int(health)) + "%")

        if health == 100:
            print("✅ System Status : EXCELLENT")
        elif health >= 80:
            print("⚠️ System Status : GOOD")
        else:
            print("❌ System Status : NEEDS ATTENTION")


# ===============================
# SYSTEM TEST
# ===============================

HEALTH = AI_System_Health_Monitor()

HEALTH.add_module("Product Analyzer", "ONLINE")
HEALTH.add_module("Pricing Optimization", "ONLINE")
HEALTH.add_module("Advertising Manager", "ONLINE")
HEALTH.add_module("Workflow Engine", "ONLINE")
HEALTH.add_module("Decision Engine", "ONLINE")
HEALTH.add_module("Inventory Manager", "ONLINE")
HEALTH.add_module("Supplier Manager", "ONLINE")
HEALTH.add_module("Smart Purchasing", "ONLINE")

HEALTH.check_health()