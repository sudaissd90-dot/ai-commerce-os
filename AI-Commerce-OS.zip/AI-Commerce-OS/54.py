# ==================================================
# AI E-COMMERCE AUTOPILOT SYSTEM
# AI ERROR RECOVERY MANAGER
# Code No: 54
# Version: 2.0
# ==================================================


class AI_Error_Recovery_Manager:

    def __init__(self):

        self.error_log = []

        print("=" * 70)
        print("🛠️ AI ERROR RECOVERY MANAGER")
        print("=" * 70)

    # ------------------------------------------------

    def detect_error(self, module_name, error_message):

        error = {
            "Module": module_name,
            "Error": error_message
        }

        self.error_log.append(error)

        print("❌ Error Detected")
        print("Module :", module_name)
        print("Error  :", error_message)

    # ------------------------------------------------

    def recover_system(self):

        print("\n🔄 RECOVERY PROCESS")
        print("-" * 50)

        if len(self.error_log) == 0:

            print("✅ No Errors Found")
            print("System Running Normally")

        else:

            for error in self.error_log:

                print("Recovering :", error["Module"])
                print("Status      : RECOVERED ✅")
                print("-" * 50)

    # ------------------------------------------------

    def show_error_log(self):

        print("\n📋 ERROR LOG")
        print("-" * 50)

        if len(self.error_log) == 0:

            print("No Errors Recorded")

        else:

            for error in self.error_log:

                print("Module :", error["Module"])
                print("Error  :", error["Error"])
                print("-" * 50)


# ===============================
# SYSTEM TEST
# ===============================

RECOVERY = AI_Error_Recovery_Manager()

RECOVERY.detect_error(
    "Pricing Optimization",
    "Price Calculation Timeout"
)

RECOVERY.detect_error(
    "Advertising Manager",
    "Campaign API Not Responding"
)

RECOVERY.recover_system()

RECOVERY.show_error_log()