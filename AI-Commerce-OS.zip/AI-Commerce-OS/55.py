# ==================================================
# AI E-COMMERCE AUTOPILOT SYSTEM
# AI ACTIVITY LOGGER
# Code No: 55
# Version: 2.0
# ==================================================

from datetime import datetime


class AI_Activity_Logger:

    def __init__(self):

        self.logs = []

        print("=" * 70)
        print("📝 AI ACTIVITY LOGGER")
        print("=" * 70)

    # ------------------------------------------------

    def log_activity(self, module_name, activity):

        current_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

        log = {
            "Time": current_time,
            "Module": module_name,
            "Activity": activity
        }

        self.logs.append(log)

        print("✅ Activity Logged:", module_name)

    # ------------------------------------------------

    def show_logs(self):

        print("\n📋 ACTIVITY LOG")
        print("-" * 50)

        if len(self.logs) == 0:

            print("No Activity Recorded")

        else:

            for log in self.logs:

                print("Time     :", log["Time"])
                print("Module   :", log["Module"])
                print("Activity :", log["Activity"])
                print("-" * 50)


# ===============================
# SYSTEM TEST
# ===============================

LOGGER = AI_Activity_Logger()

LOGGER.log_activity(
    "Product Analyzer",
    "Product Analysis Completed"
)

LOGGER.log_activity(
    "Pricing Optimization",
    "Price Updated"
)

LOGGER.log_activity(
    "Advertising Manager",
    "Campaign Created"
)

LOGGER.show_logs()