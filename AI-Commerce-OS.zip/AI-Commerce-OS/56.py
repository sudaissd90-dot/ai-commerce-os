# ==================================================
# AI E-COMMERCE AUTOPILOT SYSTEM
# AI NOTIFICATION MANAGER
# Code No: 56
# Version: 2.0
# ==================================================


class AI_Notification_Manager:

    def __init__(self):

        self.notifications = []

        print("=" * 70)
        print("🔔 AI NOTIFICATION MANAGER")
        print("=" * 70)

    # ------------------------------------------------

    def send_notification(self, category, message):

        notification = {
            "Category": category,
            "Message": message
        }

        self.notifications.append(notification)

        print("✅ Notification Sent")

    # ------------------------------------------------

    def show_notifications(self):

        print("\n📢 NOTIFICATION CENTER")
        print("-" * 50)

        if len(self.notifications) == 0:

            print("No Notifications")

        else:

            number = 1

            for notification in self.notifications:

                print("Notification", number)
                print("Category :", notification["Category"])
                print("Message  :", notification["Message"])
                print("-" * 50)

                number += 1


# ===============================
# SYSTEM TEST
# ===============================

NOTIFY = AI_Notification_Manager()

NOTIFY.send_notification(
    "Inventory",
    "Low Stock Detected"
)

NOTIFY.send_notification(
    "Pricing",
    "Selling Price Updated"
)

NOTIFY.send_notification(
    "Advertising",
    "Campaign Successfully Launched"
)

NOTIFY.show_notifications()