# ==================================================
# AI E-COMMERCE AUTOPILOT SYSTEM
# AI ANALYTICS DASHBOARD
# Code No: 57
# Version: 2.0
# ==================================================


class AI_Analytics_Dashboard:

    def __init__(self):

        print("=" * 70)
        print("📊 AI ANALYTICS DASHBOARD")
        print("=" * 70)

    # ------------------------------------------------

    def show_dashboard(
        self,
        total_products,
        total_orders,
        total_revenue,
        total_stock
    ):

        print("\n📈 BUSINESS SUMMARY")
        print("-" * 50)

        print("📦 Total Products :", total_products)
        print("🛒 Total Orders   :", total_orders)
        print("💰 Total Revenue  : $", total_revenue)
        print("📦 Total Stock    :", total_stock)

        print("\n🤖 AI STATUS")
        print("-" * 50)

        if total_orders >= 100:
            print("🚀 Sales Performance : EXCELLENT")
        elif total_orders >= 50:
            print("✅ Sales Performance : GOOD")
        else:
            print("⚠️ Sales Performance : NEEDS IMPROVEMENT")

        print("\n✅ Dashboard Generated Successfully")


# ===============================
# SYSTEM TEST
# ===============================

DASHBOARD = AI_Analytics_Dashboard()

DASHBOARD.show_dashboard(
    total_products=3,
    total_orders=120,
    total_revenue=2500,
    total_stock=350
)