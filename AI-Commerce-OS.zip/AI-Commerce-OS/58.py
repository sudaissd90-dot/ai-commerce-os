# ==================================================
# AI E-COMMERCE AUTOPILOT SYSTEM
# AI SALES PERFORMANCE TRACKER
# Code No: 58
# Version: 2.0
# ==================================================


class AI_Sales_Performance_Tracker:

    def __init__(self):

        print("=" * 70)
        print("📈 AI SALES PERFORMANCE TRACKER")
        print("=" * 70)


    # ------------------------------------------------

    def show_report(
        self,
        daily_sales,
        weekly_sales,
        monthly_sales,
        best_product
    ):

        print("\n📊 SALES REPORT")
        print("-" * 50)


        print("💰 Daily Sales   : $", daily_sales)
        print("📅 Weekly Sales  : $", weekly_sales)
        print("📆 Monthly Sales : $", monthly_sales)
        print("🏆 Best Product  :", best_product)


        print("\n🤖 AI PERFORMANCE")
        print("-" * 50)


        if monthly_sales >= 10000:

            print("🚀 Business Growth : EXCELLENT")


        elif monthly_sales >= 5000:

            print("✅ Business Growth : GOOD")


        else:

            print("⚠️ Business Growth : NEEDS IMPROVEMENT")


        print("\n✅ Sales Report Generated Successfully")



# ===============================
# SYSTEM TEST
# ===============================

TRACKER = AI_Sales_Performance_Tracker()


TRACKER.show_report(
    daily_sales=250,
    weekly_sales=1800,
    monthly_sales=12000,
    best_product="Car Phone Holder"
)