# ==================================================
# AI E-COMMERCE AUTOPILOT SYSTEM
# AI PROFIT CALCULATOR PRO
# Code No: 59
# Version: 2.0
# ==================================================


class AI_Profit_Calculator_Pro:

    def __init__(self):

        print("=" * 70)
        print("💰 AI PROFIT CALCULATOR PRO")
        print("=" * 70)


    # ------------------------------------------------

    def calculate_profit(
        self,
        selling_price,
        product_cost,
        quantity
    ):

        revenue = selling_price * quantity

        cost = product_cost * quantity

        profit = revenue - cost

        margin = (profit / revenue) * 100


        print("\n📊 PROFIT REPORT")
        print("-" * 50)


        print("💵 Total Revenue : $", revenue)
        print("📦 Total Cost    : $", cost)
        print("📈 Net Profit    : $", profit)
        print("📊 Profit Margin :", round(margin, 2), "%")


        print("\n🤖 AI PROFIT DECISION")
        print("-" * 50)


        if margin >= 50:

            print("🚀 Strategy : HIGH PROFIT PRODUCT")


        elif margin >= 30:

            print("✅ Strategy : GOOD PROFIT PRODUCT")


        else:

            print("⚠️ Strategy : LOW PROFIT PRODUCT")


        print("\n✅ Profit Analysis Completed")



# ===============================
# SYSTEM TEST
# ===============================

PROFIT = AI_Profit_Calculator_Pro()


PROFIT.calculate_profit(
    selling_price=18,
    product_cost=5,
    quantity=100
)