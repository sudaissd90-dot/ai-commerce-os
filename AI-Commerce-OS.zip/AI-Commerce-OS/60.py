# ==================================================
# AI E-COMMERCE AUTOPILOT SYSTEM
# AI CUSTOMER ORDER MANAGER
# Code No: 60
# Version: 2.0
# ==================================================


class AI_Customer_Order_Manager:

    def __init__(self):

        self.orders = []

        print("=" * 70)
        print("🛒 AI CUSTOMER ORDER MANAGER")
        print("=" * 70)


    # ------------------------------------------------

    def add_order(
        self,
        customer,
        product,
        quantity,
        price
    ):

        order = {

            "Customer": customer,
            "Product": product,
            "Quantity": quantity,
            "Price": price

        }


        self.orders.append(order)

        print("✅ Order Added:", customer)



    # ------------------------------------------------

    def show_orders(self):

        print("\n📋 ORDER REPORT")
        print("-" * 50)


        total_sales = 0


        for order in self.orders:


            amount = order["Quantity"] * order["Price"]

            total_sales += amount


            print("\nCustomer :", order["Customer"])
            print("Product  :", order["Product"])
            print("Quantity :", order["Quantity"])
            print("Amount   : $", amount)

            print("-" * 50)



        print("💰 Total Sales : $", total_sales)


        print("\n✅ Order Management Completed")



# ===============================
# SYSTEM TEST
# ===============================

ORDERS = AI_Customer_Order_Manager()


ORDERS.add_order(
    "Customer A",
    "Car Phone Holder",
    2,
    18
)


ORDERS.add_order(
    "Customer B",
    "LED Cabinet Light",
    3,
    15
)


ORDERS.show_orders()