# ==================================================
# AI E-COMMERCE AUTOPILOT SYSTEM
# AI CUSTOMER DATABASE MANAGER
# Code No: 61
# Version: 2.0
# ==================================================


class AI_Customer_Database_Manager:

    def __init__(self):

        self.customers = []

        print("=" * 70)
        print("👤 AI CUSTOMER DATABASE MANAGER")
        print("=" * 70)


    # ------------------------------------------------

    def add_customer(
        self,
        customer_id,
        name,
        email,
        total_orders
    ):

        customer = {

            "ID": customer_id,
            "Name": name,
            "Email": email,
            "Orders": total_orders

        }


        self.customers.append(customer)

        print("✅ Customer Added:", name)



    # ------------------------------------------------

    def show_customers(self):

        print("\n📋 CUSTOMER DATABASE")
        print("-" * 50)


        for customer in self.customers:

            print("\nCustomer ID :", customer["ID"])
            print("Name        :", customer["Name"])
            print("Email       :", customer["Email"])
            print("Orders      :", customer["Orders"])

            print("-" * 50)


        print("\n✅ Customer Database Loaded")



# ===============================
# SYSTEM TEST
# ===============================

CUSTOMER_DB = AI_Customer_Database_Manager()


CUSTOMER_DB.add_customer(
    1,
    "Ali",
    "ali@example.com",
    5
)


CUSTOMER_DB.add_customer(
    2,
    "Ahmed",
    "ahmed@example.com",
    3
)


CUSTOMER_DB.show_customers()