# ==================================================
# AI E-COMMERCE AUTOPILOT SYSTEM
# AI CUSTOMER BEHAVIOR ANALYZER
# Code No: 62
# Version: 2.0
# ==================================================


class AI_Customer_Behavior_Analyzer:

    def __init__(self):

        print("=" * 70)
        print("🧠 AI CUSTOMER BEHAVIOR ANALYZER")
        print("=" * 70)


    # ------------------------------------------------

    def analyze_customer(
        self,
        name,
        total_orders,
        total_spent
    ):

        print("\n📊 CUSTOMER ANALYSIS")
        print("-" * 50)


        print("Customer :", name)
        print("Orders   :", total_orders)
        print("Spent    : $", total_spent)


        print("\n🤖 AI CUSTOMER DECISION")
        print("-" * 50)


        if total_spent >= 500:

            print("⭐ Customer Type : VIP")
            print("🎁 Action : Offer Premium Rewards")


        elif total_spent >= 200:

            print("✅ Customer Type : Regular")
            print("📢 Action : Send Special Offers")


        else:

            print("🆕 Customer Type : New")
            print("📩 Action : Start Engagement Campaign")


        print("\n✅ Customer Analysis Completed")



# ===============================
# SYSTEM TEST
# ===============================

ANALYZER = AI_Customer_Behavior_Analyzer()


ANALYZER.analyze_customer(
    "Ali",
    5,
    600
)


ANALYZER.analyze_customer(
    "Ahmed",
    2,
    80
)