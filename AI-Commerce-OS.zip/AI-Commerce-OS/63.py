# ==================================================
# AI E-COMMERCE AUTOPILOT SYSTEM
# AI RECOMMENDATION ENGINE
# Code No: 63
# Version: 2.0
# ==================================================


class AI_Recommendation_Engine:

    def __init__(self):

        print("=" * 70)
        print("🎯 AI RECOMMENDATION ENGINE")
        print("=" * 70)


    # ------------------------------------------------

    def recommend_products(
        self,
        customer,
        previous_purchase
    ):

        print("\n👤 CUSTOMER")
        print("-" * 50)

        print("Name :", customer)

        print("\n🛒 Previous Purchase")
        print("-" * 50)

        print(previous_purchase)


        print("\n🤖 AI PRODUCT RECOMMENDATION")
        print("-" * 50)


        if "Car" in previous_purchase:

            recommendations = [
                "Car Air Freshener",
                "Car Charger",
                "Car Cleaning Kit"
            ]


        elif "LED" in previous_purchase:

            recommendations = [
                "Smart Bulb",
                "Night Lamp",
                "LED Strip Lights"
            ]


        else:

            recommendations = [
                "Wireless Earbuds",
                "Phone Stand",
                "Mini Vacuum Cleaner"
            ]


        for product in recommendations:

            print("✅", product)


        print("\n🚀 Recommendation Completed")



# ===============================
# SYSTEM TEST
# ===============================

RECOMMENDER = AI_Recommendation_Engine()


RECOMMENDER.recommend_products(
    "Ali",
    "Car Phone Holder"
)


RECOMMENDER.recommend_products(
    "Ahmed",
    "Smart LED Cabinet Light"
)