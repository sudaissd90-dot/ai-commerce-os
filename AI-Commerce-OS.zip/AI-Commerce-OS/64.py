# ==================================================
# AI E-COMMERCE AUTOPILOT SYSTEM
# AI MARKETING STRATEGY GENERATOR
# Code No: 64
# Version: 2.0
# ==================================================


class AI_Marketing_Strategy_Generator:

    def __init__(self):

        print("=" * 70)
        print("📢 AI MARKETING STRATEGY GENERATOR")
        print("=" * 70)


    # ------------------------------------------------

    def generate_strategy(
        self,
        product,
        category,
        price
    ):

        print("\n📦 PRODUCT INFORMATION")
        print("-" * 50)

        print("Product  :", product)
        print("Category :", category)
        print("Price    : $", price)


        print("\n🎯 TARGET AUDIENCE")
        print("-" * 50)


        if category == "Car Accessories":

            print("🚗 Car Owners")
            print("👨 Age Group: 20-50")


        elif category == "Home":

            print("🏠 Home Improvement Buyers")
            print("👨‍👩‍👧 Families")


        else:

            print("🌎 General Online Shoppers")



        print("\n📱 MARKETING CHANNELS")
        print("-" * 50)

        print("✅ TikTok Ads")
        print("✅ Facebook Ads")
        print("✅ Instagram Marketing")
        print("✅ Google Shopping")



        print("\n🚀 AI MARKETING PLAN")
        print("-" * 50)

        print("Strategy : Product Testing + Optimization")
        print("Goal     : Increase Sales & Brand Growth")


        print("\n✅ Marketing Strategy Generated")



# ===============================
# SYSTEM TEST
# ===============================

MARKETING = AI_Marketing_Strategy_Generator()


MARKETING.generate_strategy(
    "Car Phone Holder",
    "Car Accessories",
    18
)