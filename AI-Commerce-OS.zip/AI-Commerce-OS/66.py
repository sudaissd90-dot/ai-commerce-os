# ==================================================
# AI E-COMMERCE AUTOPILOT SYSTEM
# AI PRODUCT RANKING SYSTEM
# Code No: 66
# Version: 2.0
# ==================================================


class AI_Product_Ranking_System:

    def __init__(self):

        self.products = []

        print("=" * 70)
        print("🏆 AI PRODUCT RANKING SYSTEM")
        print("=" * 70)


    # ------------------------------------------------

    def add_product(
        self,
        name,
        demand_score,
        profit_score,
        competition_score
    ):

        total_score = (
            demand_score +
            profit_score +
            competition_score
        )


        product = {

            "Name": name,
            "Score": total_score

        }


        self.products.append(product)



    # ------------------------------------------------

    def show_ranking(self):

        print("\n📊 PRODUCT RANKING")
        print("-" * 50)


        self.products.sort(
            key=lambda x: x["Score"],
            reverse=True
        )


        rank = 1


        for product in self.products:

            print(
                rank,
                "🏆",
                product["Name"],
                "- Score:",
                product["Score"]
            )

            rank += 1



        print("\n🚀 Best Product:",
              self.products[0]["Name"])


        print("\n✅ Ranking Completed")



# ===============================
# SYSTEM TEST
# ===============================

RANKING = AI_Product_Ranking_System()


RANKING.add_product(
    "Car Phone Holder",
    9,
    10,
    8
)


RANKING.add_product(
    "LED Cabinet Light",
    8,
    7,
    9
)


RANKING.add_product(
    "Mini Vacuum Cleaner",
    7,
    8,
    6
)


RANKING.show_ranking()