# ==================================================
# AI E-COMMERCE AUTOPILOT SYSTEM
# AI PRODUCT TREND PREDICTOR
# Code No: 67
# Version: 2.0
# ==================================================


class AI_Product_Trend_Predictor:

    def __init__(self):

        print("=" * 70)
        print("📈 AI PRODUCT TREND PREDICTOR")
        print("=" * 70)


    # ------------------------------------------------

    def predict_trend(
        self,
        product,
        demand,
        search_growth,
        competition
    ):

        print("\n📦 PRODUCT ANALYSIS")
        print("-" * 50)

        print("Product     :", product)
        print("Demand      :", demand)
        print("Search Growth:", search_growth)
        print("Competition :", competition)


        trend_score = (
            demand +
            search_growth -
            competition
        )


        print("\n🤖 AI TREND DECISION")
        print("-" * 50)


        print("Trend Score :", trend_score)


        if trend_score >= 15:

            print("🔥 Trend Status : HIGH DEMAND")
            print("🚀 Action : Promote Product")


        elif trend_score >= 8:

            print("✅ Trend Status : GROWING")
            print("📢 Action : Test Marketing")


        else:

            print("⚠️ Trend Status : LOW TREND")
            print("🛑 Action : Monitor Product")



        print("\n✅ Trend Prediction Completed")



# ===============================
# SYSTEM TEST
# ===============================

TREND = AI_Product_Trend_Predictor()


TREND.predict_trend(
    "Car Phone Holder",
    9,
    10,
    3
)