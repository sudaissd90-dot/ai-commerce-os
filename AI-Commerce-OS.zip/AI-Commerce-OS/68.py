# ==================================================
# AI E-COMMERCE AUTOPILOT SYSTEM
# AI SALES FORECASTING SYSTEM
# Code No: 68
# Version: 2.0
# ==================================================


class AI_Sales_Forecasting_System:

    def __init__(self):

        print("=" * 70)
        print("📈 AI SALES FORECASTING SYSTEM")
        print("=" * 70)


    # ------------------------------------------------

    def forecast_sales(
        self,
        current_sales,
        growth_rate,
        months
    ):

        print("\n📊 SALES FORECAST REPORT")
        print("-" * 50)


        print("Current Monthly Sales : $", current_sales)
        print("Growth Rate           :", growth_rate, "%")
        print("Forecast Period       :", months, "Months")


        future_sales = current_sales


        for month in range(1, months + 1):

            future_sales = future_sales + (
                future_sales * growth_rate / 100
            )


            print(
                "Month",
                month,
                "Expected Sales: $",
                round(future_sales, 2)
            )


        print("\n🤖 AI BUSINESS DECISION")
        print("-" * 50)


        if future_sales >= 20000:

            print("🚀 Growth Status : HIGH SCALE")

        elif future_sales >= 10000:

            print("✅ Growth Status : STABLE GROWTH")

        else:

            print("⚠️ Growth Status : NEEDS IMPROVEMENT")


        print("\n✅ Sales Forecast Completed")



# ===============================
# SYSTEM TEST
# ===============================

FORECAST = AI_Sales_Forecasting_System()


FORECAST.forecast_sales(
    current_sales=12000,
    growth_rate=10,
    months=3
)