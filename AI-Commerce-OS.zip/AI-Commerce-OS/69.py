# ==================================================
# AI E-COMMERCE AUTOPILOT SYSTEM
# AI BUSINESS GROWTH ANALYZER
# Code No: 69
# Version: 2.0
# ==================================================


class AI_Business_Growth_Analyzer:

    def __init__(self):

        print("=" * 70)
        print("📊 AI BUSINESS GROWTH ANALYZER")
        print("=" * 70)


    # ------------------------------------------------

    def analyze_growth(
        self,
        previous_revenue,
        current_revenue,
        customers
    ):

        print("\n📈 GROWTH REPORT")
        print("-" * 50)


        print("Previous Revenue : $", previous_revenue)
        print("Current Revenue  : $", current_revenue)
        print("Total Customers  :", customers)


        growth = (
            (current_revenue - previous_revenue)
            /
            previous_revenue
        ) * 100


        print("Growth Rate      :", round(growth, 2), "%")


        print("\n🤖 AI BUSINESS DECISION")
        print("-" * 50)


        if growth >= 50:

            print("🚀 Business Status : RAPID GROWTH")
            print("Strategy : Scale Marketing")


        elif growth >= 20:

            print("✅ Business Status : HEALTHY GROWTH")
            print("Strategy : Continue Optimization")


        else:

            print("⚠️ Business Status : SLOW GROWTH")
            print("Strategy : Improve Sales Plan")


        print("\n✅ Growth Analysis Completed")



# ===============================
# SYSTEM TEST
# ===============================

GROWTH = AI_Business_Growth_Analyzer()


GROWTH.analyze_growth(
    previous_revenue=10000,
    current_revenue=15000,
    customers=250
)