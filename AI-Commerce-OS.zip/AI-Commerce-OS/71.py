# ==================================================
# AI E-COMMERCE AUTOPILOT SYSTEM
# AI AUTOMATION SCHEDULER
# Code No: 71
# Version: 2.0
# ==================================================


class AI_Automation_Scheduler:

    def __init__(self):

        self.tasks = []

        print("=" * 70)
        print("⏰ AI AUTOMATION SCHEDULER")
        print("=" * 70)


    # ------------------------------------------------

    def add_task(
        self,
        task_name,
        schedule_time
    ):

        task = {

            "Task": task_name,
            "Time": schedule_time

        }


        self.tasks.append(task)

        print("✅ Task Scheduled:", task_name)



    # ------------------------------------------------

    def show_schedule(self):

        print("\n📅 AUTOMATION SCHEDULE")
        print("-" * 50)


        for task in self.tasks:

            print("Task :", task["Task"])
            print("Time :", task["Time"])
            print("-" * 50)


        print("\n🤖 AI Automation Status : ACTIVE")
        print("✅ Scheduler Running Successfully")



# ===============================
# SYSTEM TEST
# ===============================

SCHEDULER = AI_Automation_Scheduler()


SCHEDULER.add_task(
    "Inventory Check",
    "09:00 AM"
)


SCHEDULER.add_task(
    "Sales Report Generation",
    "06:00 PM"
)


SCHEDULER.add_task(
    "Marketing Campaign Review",
    "08:00 PM"
)


SCHEDULER.show_schedule()