# ==================================================
# AI E-COMMERCE AUTOPILOT SYSTEM
# AI TASK MANAGER SYSTEM
# Code No: 72
# Version: 2.0
# ==================================================


class AI_Task_Manager_System:

    def __init__(self):

        self.tasks = []

        print("=" * 70)
        print("📋 AI TASK MANAGER SYSTEM")
        print("=" * 70)


    # ------------------------------------------------

    def add_task(
        self,
        task_name,
        department,
        status
    ):

        task = {

            "Task": task_name,
            "Department": department,
            "Status": status

        }


        self.tasks.append(task)

        print("✅ Task Added:", task_name)



    # ------------------------------------------------

    def show_tasks(self):

        print("\n📊 TASK MANAGEMENT REPORT")
        print("-" * 50)


        for task in self.tasks:

            print("\nTask       :", task["Task"])
            print("Department :", task["Department"])
            print("Status     :", task["Status"])

            print("-" * 50)



        print("\n🤖 AI Task Manager Status : ONLINE")
        print("✅ All Tasks Organized Successfully")



# ===============================
# SYSTEM TEST
# ===============================

TASK_MANAGER = AI_Task_Manager_System()


TASK_MANAGER.add_task(
    "Find New Products",
    "Product Research",
    "COMPLETED"
)


TASK_MANAGER.add_task(
    "Update Product Prices",
    "Pricing",
    "PENDING"
)


TASK_MANAGER.add_task(
    "Run Advertising Campaign",
    "Marketing",
    "ACTIVE"
)


TASK_MANAGER.show_tasks()