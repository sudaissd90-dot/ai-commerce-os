# ==================================================
# AI E-COMMERCE AUTOPILOT SYSTEM
# AI DECISION AUTOMATION ENGINE
# Code No: 74
# Version: 2.0
# ==================================================


class AI_Decision_Automation_Engine:

    def __init__(self):

        print("=" * 70)
        print("🧠 AI DECISION AUTOMATION ENGINE")
        print("=" * 70)


    # ------------------------------------------------

    def make_decision(
        self,
        sales_score,
        profit_score,
        demand_score
    ):

        print("\n📊 DECISION FACTORS")
        print("-" * 50)


        print("Sales Score  :", sales_score)
        print("Profit Score :", profit_score)
        print("Demand Score :", demand_score)


        total_score = (
            sales_score +
            profit_score +
            demand_score
        )


        print("\n🤖 AI DECISION REPORT")
        print("-" * 50)

        print("Total Score :", total_score)



        if total_score >= 25:

            print("🚀 Decision : SCALE PRODUCT")
            print("Action : Increase Marketing Budget")


        elif total_score >= 15:

            print("✅ Decision : CONTINUE TESTING")
            print("Action : Optimize Campaign")


        else:

            print("⚠️ Decision : REVIEW PRODUCT")
            print("Action : Analyze Again")



        print("\n✅ Decision Automation Completed")



# ===============================
# SYSTEM TEST
# ===============================

DECISION_AI = AI_Decision_Automation_Engine()


DECISION_AI.make_decision(
    sales_score=9,
    profit_score=10,
    demand_score=8
)