# ==================================================
# AI E-COMMERCE AUTOPILOT SYSTEM
# AI GLOBAL MARKET ANALYZER
# Code No: 77
# Version: 2.0
# ==================================================


class AI_Global_Market_Analyzer:

    def __init__(self):

        self.markets = []

        print("=" * 70)
        print("🌍 AI GLOBAL MARKET ANALYZER")
        print("=" * 70)



    # ------------------------------------------------

    def add_market(
        self,
        country,
        demand_score,
        competition_score
    ):

        market_score = (
            demand_score -
            competition_score
        )


        self.markets.append({

            "Country": country,
            "Score": market_score

        })



    # ------------------------------------------------

    def analyze_markets(self):

        print("\n📊 GLOBAL MARKET REPORT")
        print("-" * 50)


        self.markets.sort(
            key=lambda x: x["Score"],
            reverse=True
        )


        for market in self.markets:

            print(
                "🌍",
                market["Country"],
                "- Market Score:",
                market["Score"]
            )


        print("\n🚀 BEST MARKET:")
        print(
            self.markets[0]["Country"]
        )


        print("\n✅ Global Market Analysis Completed")



# ===============================
# SYSTEM TEST
# ===============================

MARKET_AI = AI_Global_Market_Analyzer()


MARKET_AI.add_market(
    "USA",
    10,
    4
)


MARKET_AI.add_market(
    "UK",
    8,
    3
)


MARKET_AI.add_market(
    "Saudi Arabia",
    9,
    5
)


MARKET_AI.analyze_markets()