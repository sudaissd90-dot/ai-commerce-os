# ==================================================
# AI E-COMMERCE AUTOPILOT SYSTEM
# AI GLOBAL EXPANSION PLANNER
# Code No: 78
# Version: 2.0
# ==================================================


class AI_Global_Expansion_Planner:

    def __init__(self):

        print("=" * 70)
        print("🌍 AI GLOBAL EXPANSION PLANNER")
        print("=" * 70)



    # ------------------------------------------------

    def create_plan(
        self,
        country,
        product,
        demand_score
    ):

        print("\n📊 EXPANSION REPORT")
        print("-" * 50)


        print("Target Country :", country)
        print("Product        :", product)
        print("Demand Score   :", demand_score)


        print("\n🤖 AI EXPANSION STRATEGY")
        print("-" * 50)


        if demand_score >= 8:

            print("🚀 Market Decision : ENTER MARKET")
            print("Strategy : Fast Product Launch")


        elif demand_score >= 5:

            print("✅ Market Decision : TEST MARKET")
            print("Strategy : Small Budget Testing")


        else:

            print("⚠️ Market Decision : AVOID MARKET")
            print("Strategy : Research More")



        print("\n📢 MARKETING PLAN")
        print("-" * 50)

        print("✅ Social Media Advertising")
        print("✅ Influencer Marketing")
        print("✅ Search Ads Optimization")


        print("\n✅ Global Expansion Plan Completed")



# ===============================
# SYSTEM TEST
# ===============================

EXPANSION_AI = AI_Global_Expansion_Planner()


EXPANSION_AI.create_plan(
    country="USA",
    product="Car Phone Holder",
    demand_score=10
)