# ==================================================
# AI E-COMMERCE AUTOPILOT SYSTEM
# AI ENTERPRISE MANAGEMENT SYSTEM
# Code No: 79
# Version: 2.0
# ==================================================


class AI_Enterprise_Management_System:

    def __init__(self):

        self.departments = []

        print("=" * 70)
        print("🏢 AI ENTERPRISE MANAGEMENT SYSTEM")
        print("=" * 70)



    # ------------------------------------------------

    def add_department(
        self,
        name,
        manager,
        status
    ):

        self.departments.append({

            "Department": name,
            "Manager": manager,
            "Status": status

        })


        print(
            "✅ Department Added:",
            name
        )



    # ------------------------------------------------

    def show_enterprise(self):

        print("\n📊 ENTERPRISE REPORT")
        print("-" * 50)


        for dept in self.departments:

            print("\nDepartment :",
                  dept["Department"])

            print("Manager    :",
                  dept["Manager"])

            print("Status     :",
                  dept["Status"])

            print("-" * 50)



        print("\n🤖 AI Enterprise Status : ONLINE")
        print("🏢 All Departments Managed Successfully")



# ===============================
# SYSTEM TEST
# ===============================

ENTERPRISE = AI_Enterprise_Management_System()


ENTERPRISE.add_department(
    "Product Research",
    "AI Product Manager",
    "ACTIVE"
)


ENTERPRISE.add_department(
    "Marketing",
    "AI Marketing Manager",
    "ACTIVE"
)


ENTERPRISE.add_department(
    "Inventory",
    "AI Inventory Manager",
    "ONLINE"
)


ENTERPRISE.add_department(
    "Customer Support",
    "AI Support Manager",
    "ONLINE"
)


ENTERPRISE.show_enterprise()