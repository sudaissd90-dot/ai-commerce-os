# ==================================================
# AI E-COMMERCE AUTOPILOT SYSTEM
# AI SELF LEARNING ENGINE
# Code No: 81
# Version: 2.0
# ==================================================


class AI_Self_Learning_Engine:

    def __init__(self):

        self.learning_data = []

        print("=" * 70)
        print("🧠 AI SELF LEARNING ENGINE")
        print("=" * 70)



    # ------------------------------------------------

    def add_experience(
        self,
        decision,
        result
    ):

        self.learning_data.append({

            "Decision": decision,
            "Result": result

        })


        print(
            "✅ Learning Added:",
            decision
        )



    # ------------------------------------------------

    def analyze_learning(self):

        print("\n📚 AI LEARNING REPORT")
        print("-" * 50)


        success = 0
        total = len(self.learning_data)


        for data in self.learning_data:

            print("\nDecision :",
                  data["Decision"])

            print("Result   :",
                  data["Result"])


            if data["Result"] == "SUCCESS":

                success += 1



        accuracy = (
            success / total
        ) * 100


        print("\n🤖 AI LEARNING ACCURACY:",
              round(accuracy,2),
              "%")



        if accuracy >= 80:

            print("🚀 AI Improvement Status : LEARNING FAST")

        else:

            print("⚠️ AI Improvement Status : NEEDS MORE DATA")


        print("\n✅ Self Learning Analysis Completed")



# ===============================
# SYSTEM TEST
# ===============================

LEARNING_AI = AI_Self_Learning_Engine()


LEARNING_AI.add_experience(
    "Launch Car Phone Holder",
    "SUCCESS"
)


LEARNING_AI.add_experience(
    "Increase Advertising Budget",
    "SUCCESS"
)


LEARNING_AI.add_experience(
    "New Product Test",
    "FAILED"
)


LEARNING_AI.analyze_learning()