# ==================================================
# AI E-COMMERCE AUTOPILOT SYSTEM
# AI BUSINESS INTELLIGENCE CENTER
# Code No: 84
# Version: 2.0
# ==================================================


class AI_Business_Intelligence_Center:

    def __init__(self):

        print("=" * 70)
        print("📊 AI BUSINESS INTELLIGENCE CENTER")
        print("=" * 70)



    # ------------------------------------------------

    def generate_report(
        self,
        revenue,
        orders,
        customers,
        products
    ):

        print("\n📈 BUSINESS INTELLIGENCE REPORT")
        print("-" * 50)


        print("💰 Total Revenue :", "$", revenue)
        print("🛒 Total Orders  :", orders)
        print("👥 Customers     :", customers)
        print("📦 Products      :", products)



        average_order = revenue / orders


        print(
            "📊 Average Order Value :",
            "$",
            round(average_order,2)
        )



        print("\n🤖 AI BUSINESS INSIGHTS")
        print("-" * 50)


        if average_order >= 30:

            print("🚀 Customer Value : HIGH")
            print("Strategy : Increase Premium Products")


        else:

            print("✅ Customer Value : NORMAL")
            print("Strategy : Improve Upselling")



        if customers >= 500:

            print("📈 Customer Base : STRONG")

        else:

            print("⚠️ Customer Base : Needs Growth")



        print("\n✅ Business Intelligence Report Completed")



# ===============================
# SYSTEM TEST
# ===============================

BI_AI = AI_Business_Intelligence_Center()


BI_AI.generate_report(
    revenue=25000,
    orders=500,
    customers=800,
    products=100
)