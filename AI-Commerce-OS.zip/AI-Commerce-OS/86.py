# ==================================================
# AI E-COMMERCE AUTOPILOT SYSTEM
# AI CEO DECISION SYSTEM
# Code No: 86
# Version: 2.0
# ==================================================


class AI_CEO_Decision_System:

    def __init__(self):

        print("=" * 70)
        print("👑 AI CEO DECISION SYSTEM")
        print("=" * 70)



    # ------------------------------------------------

    def make_ceo_decision(
        self,
        profit_score,
        growth_score,
        market_score,
        risk_score
    ):

        print("\n📊 CEO DECISION FACTORS")
        print("-" * 50)


        print("Profit Score :", profit_score)
        print("Growth Score :", growth_score)
        print("Market Score :", market_score)
        print("Risk Score   :", risk_score)



        final_score = (
            profit_score +
            growth_score +
            market_score -
            risk_score
        )


        print("\n👑 CEO ANALYSIS REPORT")
        print("-" * 50)


        print(
            "Final Decision Score :",
            final_score
        )



        if final_score >= 30:

            print("🚀 CEO Decision : SCALE BUSINESS")
            print("Action : Global Expansion + More Investment")


        elif final_score >= 15:

            print("✅ CEO Decision : GROW CAREFULLY")
            print("Action : Optimize Before Scaling")


        else:

            print("⚠️ CEO Decision : REVIEW STRATEGY")
            print("Action : Reduce Risk")



        print("\n✅ CEO Decision Completed")



# ===============================
# SYSTEM TEST
# ===============================

CEO_AI = AI_CEO_Decision_System()


CEO_AI.make_ceo_decision(
    profit_score=10,
    growth_score=10,
    market_score=9,
    risk_score=2
)