# ==================================================
# AI E-COMMERCE AUTOPILOT SYSTEM
# AI COMPANY OPERATING SYSTEM
# Code No: 87
# Version: 2.0
# ==================================================


class AI_Company_Operating_System:

    def __init__(self):

        self.operations = []

        print("=" * 70)
        print("🏢 AI COMPANY OPERATING SYSTEM")
        print("=" * 70)



    # ------------------------------------------------

    def add_operation(
        self,
        department,
        task,
        status
    ):

        self.operations.append({

            "Department": department,
            "Task": task,
            "Status": status

        })


        print(
            "✅ Operation Added:",
            task
        )



    # ------------------------------------------------

    def run_system_report(self):

        print("\n📊 COMPANY OPERATIONS REPORT")
        print("-" * 50)


        for operation in self.operations:

            print("\nDepartment :",
                  operation["Department"])

            print("Task       :",
                  operation["Task"])

            print("Status     :",
                  operation["Status"])

            print("-" * 50)



        print("\n🤖 Company OS Status : ONLINE")
        print("🚀 All Operations Running Successfully")



# ===============================
# SYSTEM TEST
# ===============================

COMPANY_OS = AI_Company_Operating_System()


COMPANY_OS.add_operation(
    "Product Department",
    "Analyze New Products",
    "ACTIVE"
)


COMPANY_OS.add_operation(
    "Marketing Department",
    "Optimize Campaigns",
    "ACTIVE"
)


COMPANY_OS.add_operation(
    "Sales Department",
    "Manage Customer Orders",
    "ONLINE"
)


COMPANY_OS.add_operation(
    "Finance Department",
    "Monitor Revenue",
    "ONLINE"
)


COMPANY_OS.run_system_report()