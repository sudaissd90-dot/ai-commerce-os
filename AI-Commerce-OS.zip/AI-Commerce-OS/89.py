# ==================================================
# AI E-COMMERCE AUTOPILOT SYSTEM
# AI AUTONOMOUS COMPANY BRAIN
# Code No: 89
# Version: 2.0
# ==================================================


class AI_Autonomous_Company_Brain:

    def __init__(self):

        self.intelligence = []

        print("=" * 70)
        print("🧠 AI AUTONOMOUS COMPANY BRAIN")
        print("=" * 70)



    # ------------------------------------------------

    def add_intelligence(
        self,
        department,
        performance,
        status
    ):

        self.intelligence.append({

            "Department": department,
            "Performance": performance,
            "Status": status

        })


        print(
            "✅ Intelligence Added:",
            department
        )



    # ------------------------------------------------

    def analyze_company(self):

        print("\n📊 COMPANY BRAIN ANALYSIS")
        print("-" * 50)


        total_score = 0


        for data in self.intelligence:

            print("\nDepartment :",
                  data["Department"])

            print("Performance:",
                  data["Performance"])

            print("Status     :",
                  data["Status"])

            total_score += data["Performance"]

            print("-" * 50)



        average = (
            total_score /
            len(self.intelligence)
        )


        print("\n🧠 AI COMPANY SCORE:",
              round(average,2))


        print("\n👑 AI CEO RECOMMENDATION")
        print("-" * 50)


        if average >= 80:

            print("🚀 Decision : EXPAND COMPANY")
            print("Action : Increase Investment")


        elif average >= 50:

            print("✅ Decision : OPTIMIZE COMPANY")
            print("Action : Improve Operations")


        else:

            print("⚠️ Decision : REVIEW COMPANY")
            print("Action : Fix Weak Areas")


        print("\n✅ Company Brain Analysis Completed")



# ===============================
# SYSTEM TEST
# ===============================

BRAIN = AI_Autonomous_Company_Brain()


BRAIN.add_intelligence(
    "Product Department",
    90,
    "ACTIVE"
)


BRAIN.add_intelligence(
    "Marketing Department",
    85,
    "ACTIVE"
)


BRAIN.add_intelligence(
    "Sales Department",
    80,
    "ONLINE"
)


BRAIN.add_intelligence(
    "Finance Department",
    88,
    "ONLINE"
)


BRAIN.analyze_company()