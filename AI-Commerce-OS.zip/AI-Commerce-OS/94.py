# ==================================================
# AI E-COMMERCE AUTOPILOT SYSTEM
# AI GLOBAL BUSINESS INTELLIGENCE NETWORK
# Code No: 94
# Version: 2.0
# ==================================================


class AI_Global_Business_Intelligence_Network:

    def __init__(self):

        self.global_data = []

        print("=" * 70)
        print("🌍 AI GLOBAL BUSINESS INTELLIGENCE NETWORK")
        print("=" * 70)



    # ------------------------------------------------

    def add_market_data(
        self,
        country,
        revenue,
        demand_score
    ):

        self.global_data.append({

            "Country": country,
            "Revenue": revenue,
            "Demand": demand_score

        })


        print(
            "✅ Market Added:",
            country
        )



    # ------------------------------------------------

    def analyze_global_market(self):

        print("\n📊 GLOBAL INTELLIGENCE REPORT")
        print("-" * 50)


        total_revenue = 0
        best_market = None
        highest_demand = 0


        for market in self.global_data:

            print("\n🌍 Country:",
                  market["Country"])

            print("Revenue : $",
                  market["Revenue"])

            print("Demand Score:",
                  market["Demand"])


            total_revenue += market["Revenue"]


            if market["Demand"] > highest_demand:

                highest_demand = market["Demand"]
                best_market = market["Country"]



        print("\n💰 Global Revenue:",
              "$",
              total_revenue)


        print("🏆 Best Market:",
              best_market)



        print("\n🤖 AI GLOBAL DECISION")
        print("-" * 50)

        print("🚀 Strategy : Expand In High Demand Markets")
        print("🌍 Action : Increase Global Operations")


        print("\n✅ Global Intelligence Analysis Completed")



# ===============================
# SYSTEM TEST
# ===============================

GLOBAL_AI = AI_Global_Business_Intelligence_Network()


GLOBAL_AI.add_market_data(
    "USA",
    25000,
    95
)


GLOBAL_AI.add_market_data(
    "UK",
    15000,
    85
)


GLOBAL_AI.add_market_data(
    "Saudi Arabia",
    12000,
    88
)


GLOBAL_AI.analyze_global_market()