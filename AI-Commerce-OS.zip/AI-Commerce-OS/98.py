# ==================================================
# AI E-COMMERCE AUTOPILOT SYSTEM
# AI GLOBAL AUTONOMOUS MANAGEMENT SYSTEM
# Code No: 98
# Version: 2.0
# ==================================================


class AI_Global_Autonomous_Management_System:

    def __init__(self):

        self.regions = []

        print("=" * 70)
        print("🌍 AI GLOBAL AUTONOMOUS MANAGEMENT SYSTEM")
        print("=" * 70)



    # ------------------------------------------------

    def add_region(
        self,
        region,
        performance
    ):

        self.regions.append({

            "Region": region,
            "Performance": performance

        })


        print(
            "✅ Region Added:",
            region
        )



    # ------------------------------------------------

    def manage_global_operations(self):

        print("\n📊 GLOBAL MANAGEMENT REPORT")
        print("-" * 50)


        total = 0


        for region in self.regions:

            print("\n🌍 Region:",
                  region["Region"])

            print("Performance:",
                  region["Performance"],
                  "%")


            total += region["Performance"]



        global_score = (
            total /
            len(self.regions)
        )


        print("\n🌐 GLOBAL PERFORMANCE SCORE:",
              round(global_score,2))


        print("\n🤖 AI MANAGEMENT DECISION")
        print("-" * 50)


        if global_score >= 85:

            print("🚀 Status : GLOBAL DOMINANCE")
            print("Action : Expand Worldwide Operations")


        elif global_score >= 60:

            print("✅ Status : STABLE GLOBAL GROWTH")
            print("Action : Optimize Regions")


        else:

            print("⚠️ Status : NEEDS IMPROVEMENT")
            print("Action : Review Markets")


        print("\n✅ Global Autonomous Management Completed")



# ===============================
# SYSTEM TEST
# ===============================

GLOBAL_MANAGER = AI_Global_Autonomous_Management_System()


GLOBAL_MANAGER.add_region(
    "North America",
    95
)


GLOBAL_MANAGER.add_region(
    "Europe",
    88
)


GLOBAL_MANAGER.add_region(
    "Middle East",
    90
)


GLOBAL_MANAGER.manage_global_operations()