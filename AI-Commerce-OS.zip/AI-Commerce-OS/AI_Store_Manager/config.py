class Config:

    # ==========================================
    # DATABASE
    # ==========================================

    DATABASE_PATH = "database/ai_enterprise.db"

    # ==========================================
    # SHOPIFY
    # ==========================================

    SHOPIFY_STORE_URL = ""
    SHOPIFY_ACCESS_TOKEN = ""

    # ==========================================
    # EBAY SANDBOX
    # ==========================================

    EBAY_ENVIRONMENT = "sandbox"

    # eBay Developer Credentials
    EBAY_APP_ID = "UsmanAsl-AiStoreM-SBX-1624625de-21f7eb55"
    EBAY_CLIENT_SECRET = "SBX-624625de6962-501d-44d1-bd3d-05f1"
    EBAY_DEV_ID = "137367f6-acb9-400e-b2b7-087be6f3f73b"

    # eBay OAuth
    EBAY_USER_TOKEN = "v^1.1#i^1#f^0#I^3#p^3#r^0#t^H4sIAAAAAAAA/+Vaf2wbVx2P86Nb6LqNQTPoYLPcCjS2s++H7fMdSyoncWovPxc7P1qxeu/u3tkvuV+59y6Ji4C0EtuYkKaNsQ2kaQWmSYhFldb1L6BoQCdNm1SGUEfHr61AYQNRwQSdQEO8s5PUydY2totkaf7Huve+vz7fH++977tjl7Z0fube9L3ntwWuaj28xC61BgLcVrZzS8dt17a17uhoYasIAoeXdi21H2r78x0YmIYjj0Ps2BaGwUXTsLBcHuwOea4l2wAjLFvAhFgmqpxNDg/JfJiVHdcmtmoboWCmvzskSrrGajEWqnGoKVGBjlqrMnM2nU+IlITXNEWLCRIQ6TzGHsxYmACLdId4lo8zrMjwUo6VZJ6TBTEsSMK+UHASuhjZFiUJs6GesrlymdetsvXSpgKMoUuokFBPJjmQHU1m+lMjuTsiVbJ6VvyQJYB4eP1Tn63B4CQwPHhpNbhMLWc9VYUYhyI9FQ3rhcrJVWPqML/sah5yQIhDLs4rPKdw6hVx5YDtmoBc2g5/BGmMXiaVoUUQKV3Oo9QbygxUycrTCBWR6Q/6f3d5wEA6gm53KNWb3DuRTY2HgtmxMdeeRxrUfKScEI1GJYon1EMgpi6Ebt7DJrDERHxFV0Xgiqc3KOuzLQ35fsPBEZv0Qmo43Ogerso9lGjUGnWTOvGNqqKjRCtuTIj7/LhWAumRouWHFprUF8Hy4+WDsJoVF/LgSuWFIEGBgwLkdYET+Ti7Pi/8Wq8vN3r88CTHxiK+LVABJcYE7iwkjgFUyKjUvZ4JXaTJQkznhYQOGS0u6UxU0nVGiWlxhtMhZCFUFFVKfMBShBAXKR6Ba2mycaKMszuUVW0HjtkGUkuhjSTllWclKRZxd6hIiCNHIgsLC+EFIWy7hQjPslxkengoqxahCUJrtOjyxAwqp4cKKRdGMik51JpFmn1UuVUI9QiuNgZcUur1SvQ5Cw2D/q1m8DoLezaOXgRqn4GoH3JUUXMhTduYQK0haLQYAWkCVH6tVyGrTmd+NZ15lg7JLNsQ4KTjZEzTI0AxYEZrAuRVqKOSxHPRhuA5noeaDBWhi5fuOXguGm8Imr+OywjoMrFnodV81TieGhhPZdP53OhgaqQhpONQdyEu5nyczZajybuSe5L0N9xrLEpZKz06fkDtL5C5QTKcmIzceaDvTkud8rzZUmpIMflsbMggaWIMT6bnhmf50UivN1Xya91SBlThwEJ3d0OOykLVhc2wfFU5aHFuKpfaMz0iZganYul5wUzHx/oWOI2YU+I0HBrU4GBkzu4dzw4MNwY+15xl4FaSN1+u0jx9aghkqtB06xmI8qwK9Sgn6SyIwVgsGtWpAKjrCZGTRL7h7anJ8E74Z9MkNpgkyhJ62Bxmsr3TDO3lonE+pkGG53QRKrHY++L2a33ze1ezhfpKbV3YPys3FzSfH1MBwEFhf2cNq7YZsQHtCP2hfNni4GaIIopXovo16IZdCDTbMkqb5yt4tAOqcG+OCdPjfLjSzFEYNWpcz1wDD7LmaQNgu6V6FK4x18ADVNX2LFKPuhXWGjh0z9CRYfi9Xj0K19jL+3otioEFjBJBKq4/juWOnroYo0KR1CqHjpnQpfwqIMCwa00nP4Fx0XYcPxNV2nLWUC+6TusFeGr59qQ2Y5FWuceqF+waP10lkNGwFKdoW7BhKUDT6Kmh7gCuyfGvnBoWUrkVrasWkOWvubgGFgeUypWnIez4O0YNCwuBZlhzgV5LzflMNZC7kBoF3pulfq1vkrHecFg2QTpSKzKwp2DVRU4d9XJROfUEGPsnoFrCW2Go1wfz0LXr2qdMUF6WalRn0hIEhU3m4BqXDqGmAHW2RjZcRJe1sQob1KCBqD9KDZ3ENNtEKjKa7DA2kW3sEg9qyIUqyXsu+j8A82u90f4hTxsIYDIbegmmUNIQmdFLZkP4++F8szVNnCAKcVGPM0BVJCbKspBReEVk2ISowLgu6KKgNIS5Oa5tqxGLiZjAxRPS+zeCm7/7AobZXMgwsDTFXvxAwGqfuDiwDQNVL4je83owsv4VfU9L+ccdCrzIHgqcaA0E2D6W4W5jb93SNtHedk0I02NJeMWgMAJ6mJ7nLXoIc2F4FpYcgNzWG250/5p85KYB79iPGbI8/Viu5UNVHwocvpv92NqnAp1t3Naq7wbYT1yY6eCuu3EbH2dFXmIlnlbpPnbnhdl2rqv9o+zR3G/vTz99Hn/zUznr5INmF3m4i922RhQIdLS0Hwq0JOIPLebvOf7a2fPCk6/f/KeF5U+/8MzV381oe/NXP/XKuV/96zuFN9t/8cM/7oi9MlV85NSv50/e86OZv//m9Bt/mzl45uiJllv07ftnxh974q3dsRb5+dM7b//296fzw6/ufjcfBj+Bt5949IvB7a9O7Gr71gv/6PjKz8O/2/rx567d/pJzdnnHlxZfPPbvrvldb596V8seffaXe/55+ntj4LWnD94/cGThgWMnb3FaUp1XvXTdf7d9/vFTbx382eP5c8/d/dk3Pvf6fW3XP/DsT/u/fnPqTNr72oe/OvaFJ98JP7w8Iz7x+71d1+zf+fIfpgePzPxlf26y5T87Sp3Xv/n2y8sf2XLE+uSZp/qt3T8492jfN+aPP3P2y63PT7xz0/FKSP8HKIC26sIhAAA="
    # eBay API URLs
    EBAY_API_BASE = "https://api.sandbox.ebay.com"
    EBAY_OAUTH_URL = "https://api.sandbox.ebay.com/identity/v1/oauth2/token"
    EBAY_REFRESH_TOKEN = "YOUR_REFRESH_TOKEN_HERE"
    EBAY_ACCESS_TOKEN = ""

    # ==========================================
    # SUPPLIERS
    # ==========================================

    ALIEXPRESS_API_KEY = ""
    CJ_API_KEY = ""
    ZENDROP_API_KEY = ""

    # ==========================================
    # SHIPPING
    # ==========================================

    DHL_API_KEY = ""
    FEDEX_API_KEY = ""
    UPS_API_KEY = ""

    # ==========================================
    # PAYMENTS
    # ==========================================

    STRIPE_API_KEY = ""
    PAYPAL_API_KEY = ""

    # ==========================================
    # AI SETTINGS
    # ==========================================

    AI_ENABLED = True
    AUTO_PRODUCT_LISTING = True
    AUTO_PRICE_UPDATE = True
    AUTO_STOCK_UPDATE = True
    AUTO_ORDER_PROCESSING = True
    AUTO_MARKETING = True
    AUTO_SUPPLIER_SELECTION = True

    # ==========================================
    # SYSTEM
    # ==========================================

    DEFAULT_CURRENCY = "USD"
    DEFAULT_COUNTRY = "US"

    # ==========================================
    # LOGGING
    # ==========================================

    DEBUG_MODE = True
    LOG_LEVEL = "INFO"


config = Config()
print("Refresh Token Exists:", hasattr(config, "EBAY_REFRESH_TOKEN"))