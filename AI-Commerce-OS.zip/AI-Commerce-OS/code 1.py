# ==================================================
# AI E-COMMERCE AUTOPILOT SYSTEM
# Professional Market Project
# Version: 1.0 Foundation Core
# ==================================================

from datetime import datetime


class AI_Ecommerce_System:

    def __init__(self, store_name):
        self.store_name = store_name
        self.version = "1.0"
        self.status = "ONLINE"
        self.products = []
        self.activity_log = []

    def system_boot(self):
        print("=" * 55)
        print("🚀 AI E-COMMERCE AUTOPILOT SYSTEM")
        print("=" * 55)
        print("Store:", self.store_name)
        print("Version:", self.version)
        print("Status:", self.status)
        print("Boot Time:", datetime.now())
        print("=" * 55)

        self.log_activity("System Started")

    def log_activity(self, message):
        record = {
            "time": str(datetime.now()),
            "activity": message
        }

        self.activity_log.append(record)

    def add_product(self, name, category, price):

        for product in self.products:
            if product["name"].lower() == name.lower():
                print("\n⚠️ Duplicate Product Found")
                print("Product:", name)
                return

        new_product = {
            "name": name,
            "category": category,
            "price": price,
            "status": "ACTIVE"
        }

        self.products.append(new_product)

        self.log_activity(
            f"Product Added: {name}"
        )

        print("\n✅ New Product Added")
        print("Name:", name)
        print("Category:", category)
        print("Price:", price)

    def show_products(self):

        print("\n📦 PRODUCT DATABASE")
        print("-" * 40)

        if not self.products:
            print("Database Empty")

        else:
            for number, product in enumerate(self.products, 1):
                print(
                    number,
                    product
                )

    def system_report(self):

        print("\n📊 SYSTEM REPORT")
        print("-" * 40)
        print("Total Products:",
              len(self.products))

        print("Total Activities:",
              len(self.activity_log))


# ===============================
# SYSTEM START
# ===============================

AI_STORE = AI_Ecommerce_System(
    "Future AI Commerce Store"
)

AI_STORE.system_boot()


# Product Testing

AI_STORE.add_product(
    "Smart LED Cabinet Light",
    "Home Gadget",
    "$19.99"
)

AI_STORE.add_product(
    "Smart LED Cabinet Light",
    "Home Gadget",
    "$19.99"
)


AI_STORE.show_products()

AI_STORE.system_report()