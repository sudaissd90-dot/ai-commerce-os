# ==================================================
# AI E-COMMERCE AUTOPILOT SYSTEM
# Version: 1.1
# Advanced Product Management Engine
# ==================================================

from datetime import datetime


class ProductManager:

    def __init__(self):
        self.products = []
        self.logs = []
        self.next_id = 1001


    def add_product(self, name, category, price):

        for product in self.products:
            if product["name"].lower() == name.lower():
                print("\n⚠️ Product Already Exists")
                return


        product = {
            "id": self.next_id,
            "name": name,
            "category": category,
            "price": price,
            "status": "ACTIVE",
            "created": str(datetime.now())
        }


        self.products.append(product)
        self.next_id += 1

        self.logs.append(
            f"Added: {name}"
        )


        print("\n✅ Product Added Successfully")
        print(product)



    def search_product(self, keyword):

        print("\n🔍 SEARCH RESULT")
        print("-" * 40)

        found = False

        for product in self.products:

            if keyword.lower() in product["name"].lower():

                print(product)
                found = True


        if not found:
            print("No Product Found")



    def update_price(self, product_id, new_price):

        for product in self.products:

            if product["id"] == product_id:

                product["price"] = new_price

                print("\n✅ Price Updated")
                print(product)

                return


        print("❌ Product ID Not Found")



    def delete_product(self, product_id):

        for product in self.products:

            if product["id"] == product_id:

                self.products.remove(product)

                print("\n🗑 Product Removed")

                return


        print("❌ Product Not Found")



    def report(self):

        print("\n📊 PRODUCT REPORT")
        print("-" * 40)

        print(
            "Total Products:",
            len(self.products)
        )

        print(
            "Total Logs:",
            len(self.logs)
        )



# =========================
# TEST SYSTEM
# =========================


manager = ProductManager()


manager.add_product(
    "Smart LED Cabinet Light",
    "Home Gadget",
    "$19.99"
)


manager.add_product(
    "Wireless Car Charger",
    "Car Accessories",
    "$29.99"
)


manager.search_product(
    "LED"
)


manager.update_price(
    1001,
    "$24.99"
)


manager.report()