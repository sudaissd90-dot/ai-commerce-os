# ==================================================
# AI E-COMMERCE AUTOPILOT SYSTEM
# AI PRODUCT INTELLIGENCE ENGINE
# Code No: 2
# Version: 1.1
# ==================================================


class AI_Product_Analyzer:

    def __init__(self):
        self.engine = "ONLINE"


    def analyze_product(self, name, category, price):

        print("=" * 50)
        print("🧠 AI PRODUCT INTELLIGENCE ENGINE")
        print("=" * 50)

        print("Product:", name)
        print("Category:", category)
        print("Price:", price)


        demand_score = 8
        profit_score = 7
        competition_score = 6


        total_score = (
            demand_score +
            profit_score +
            competition_score
        )


        print("\n📊 MARKET ANALYSIS")
        print("-" * 40)

        print("Demand:", demand_score, "/10")
        print("Profit:", profit_score, "/10")
        print("Competition:", competition_score, "/10")

        print("Total Score:",
              total_score,
              "/30")


        if total_score >= 22:
            decision = "🚀 APPROVED FOR SELLING"

        elif total_score >= 15:
            decision = "⚠️ NEEDS REVIEW"

        else:
            decision = "❌ REJECT"


        print("\nAI DECISION:")
        print(decision)



# ===============================
# TEST SYSTEM
# ===============================


AI_ANALYZER = AI_Product_Analyzer()


AI_ANALYZER.analyze_product(
    "Smart LED Cabinet Light",
    "Home Gadget",
    "$19.99"
)